let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited = raise NotImplemented
   and aux_list nodes visited = raise NotImplemented in
   match g with
   | { nodes = []; edges = _ } -> raise Fail
   | { nodes = _; edges = [] } -> raise Fail
   | { nodes = ns; edges = _ } -> aux_list ns [] : ('a list * weight))
