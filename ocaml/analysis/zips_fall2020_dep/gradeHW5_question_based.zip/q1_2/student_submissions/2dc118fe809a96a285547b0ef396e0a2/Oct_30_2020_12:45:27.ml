let g =
  {
    nodes = ["Vancouver"; "Toronto"; "Ottawa"];
    edges = [("Toronto", "Ottawa", 1); ("Vancouver", "Toronto", 2)]
  }
let neighbours (g : 'a graph) (vertex : 'a) =
  (let edge l (a, b, w) = if vertex = a then (b, w) :: l else l in
   List.fold_left edge [] g.edges : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let weight = 0 in
   let rec aux_node node visited =
     if List.mem node visited
     then raise Fail
     else (match node with | (b, w) -> ((b, w) :: visited; weight + w)) in
   let rec aux_list nodes visited =
     match nodes with
     | [] -> raise Fail
     | h::t -> (try aux_node h visited with | Fail -> aux_list t visited) in
   let n = neighbours g a in aux_list n []; raise NotImplemented : ('a list *
                                                                    weight))
