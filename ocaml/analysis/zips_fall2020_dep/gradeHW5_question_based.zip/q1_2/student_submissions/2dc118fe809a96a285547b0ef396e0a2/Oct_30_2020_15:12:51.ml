let g =
  {
    nodes = ["Vancouver"; "Toronto"; "Ottawa"];
    edges = [("Toronto", "Ottawa", 1); ("Vancouver", "Toronto", 2)]
  }
let neighbours (g : 'a graph) (vertex : 'a) =
  (let edge l (a, b, w) = if vertex = a then (b, w) :: l else l in
   List.fold_left edge [] g.edges : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited weight =
     if List.mem node visited
     then raise Fail
     else
       if node = b
       then visited @ [b]
       else aux_list (neighbours g node) (visited @ [b]) weight
   and aux_list nodes visited weight =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node h visited weight
          with | Fail -> aux_list t visited weight) in
   aux_list (neighbours g a) [] 0; raise Fail : ('a list * weight))
