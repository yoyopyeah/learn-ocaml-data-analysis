let g =
  {
    nodes = ["Vancouver"; "Toronto"; "Ottawa"];
    edges = [("Toronto", "Ottawa", 1); ("Vancouver", "Toronto", 2)]
  }
let neighbours (g : 'a graph) (vertex : 'a) =
  (let edge l (a, b, w) = if vertex = a then (b, w) :: l else l in
   List.fold_left edge [] g.edges : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited =
     let (n, w) = node in
     if List.mem n visited
     then raise Fail
     else
       if n = b
       then ((visited @ [n]), w)
       else aux_list (neighbours g n) (visited @ [n]) w
   and aux_list nodes visited weight =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node (h, (weight + w)) visited
          with | Fail -> aux_list t visited w) in
   aux_node (a, 0) [] : ('a list * weight))
