let neighbours (g : 'a graph) (vertex : 'a) =
  (let f (acc : ('a * weight) list) (edge : ('a * 'a * weight)) =
     (let (v1, v2, w) = edge in if v1 = vertex then (v2, w) :: acc else acc : 
     ('a * weight) list) in
   List.fold_left f [] g.edges : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) (acc : weight)
     =
     (let (v, w) = node in
      if List.mem v visited
      then raise Fail
      else
        if v = b
        then ((v :: visited), (acc + w))
        else aux_list (neighbours g v) (v :: visited) (acc + w) : ('a list *
                                                                    weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list)
     (acc : weight) =
     (match nodes with
      | [] -> raise Fail
      | h::t ->
          (try aux_node h visited acc with | Fail -> aux_list t visited acc) : 
     ('a list * weight)) in
   aux_node (a, 0) [] 0 : ('a list * weight))
