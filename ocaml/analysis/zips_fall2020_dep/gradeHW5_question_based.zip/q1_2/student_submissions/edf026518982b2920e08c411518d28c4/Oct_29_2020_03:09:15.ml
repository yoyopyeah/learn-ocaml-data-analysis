let neighbours (g : 'a graph) (vertex : 'a) =
  (let rec neighbors' l acc =
     match l with
     | [] -> acc
     | x::xs ->
         let (v1, v2, w) = x in
         if v1 = vertex
         then neighbors' xs ((v2, w) :: acc)
         else neighbors' xs acc in
   neighbors' g.edges [] : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (n, w) = node in
      if List.exists (fun v'd_node -> v'd_node = n) visited
      then raise Fail
      else
        if n = b
        then ((n :: visited), 0)
        else aux_list (neighbours g n) (n :: visited) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | [] -> raise Fail
      | x::xs -> (try aux_node x visited with | Fail -> aux_list xs visited) : 
     ('a list * weight)) in
   aux_list (neighbours g a) [a] : ('a list * weight))
