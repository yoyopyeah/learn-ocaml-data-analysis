let neighbours (g : 'a graph) (vertex : 'a) =
  (let rec neigh_tr edge_list acc =
     match edge_list with
     | [] -> []
     | (v, neigh, w)::[] -> if v = vertex then [(neigh, w)] else []
     | h::t ->
         let (v, neigh, w) = h in
         if v = vertex
         then (neigh_tr t acc) @ [(neigh, w)]
         else neigh_tr t acc in
   neigh_tr g.edges [] : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (x, w) = node in
      if List.mem x visited
      then raise Fail
      else
        if x = b
        then (visited, w)
        else aux_list (neighbours g x) (visited @ [x]) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | [] -> raise Fail
      | h::t -> (try aux_node h visited with | Fail -> aux_list t visited) : 
     ('a list * weight)) in
   aux_list (neighbours g a) [] : ('a list * weight))
