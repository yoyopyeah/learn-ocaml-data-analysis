let neighbours (g : 'a graph) (vertex : 'a) =
  (let { nodes; edges } = g in
   let rec findneighbours edgelist node =
     match edgelist with
     | [] -> []
     | (s1, s2, w)::t ->
         if node = s1
         then (s2, w) :: (findneighbours t node)
         else findneighbours t node in
   findneighbours edges vertex : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let init = neighbours g a in
   let rec aux_list nodes visited mass =
     match nodes with
     | [] -> raise Fail
     | (node, w)::t ->
         if b = node
         then ((visited @ [b]), (mass + w))
         else
           if List.mem node visited
           then aux_list t visited mass
           else
             (try aux_list (neighbours g node) (visited @ [node]) (mass + w)
              with | Fail -> aux_list t visited mass) in
   aux_list init [] 0 : ('a list * weight))
