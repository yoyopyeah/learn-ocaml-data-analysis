let neighbours (g : 'a graph) (vertex : 'a) =
  (let extract edge acc =
     match edge with
     | (v1, v2, w) when vertex = v1 -> (v2, w) :: acc
     | (_, _, _) -> acc in
   List.fold_right extract g.edges [] : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (v, w) = node in
      if v = b
      then ([v], w)
      else
        if List.mem v visited
        then raise Fail
        else
          (let (vs, w') = aux_list (neighbours g v) (v :: visited) in
           ((v :: vs), (w + w'))) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | [] -> raise Fail
      | x::xs -> (try aux_node x visited with | Fail -> aux_list xs visited) : 
     ('a list * weight)) in
   aux_node (a, 0) [] : ('a list * weight))
