let neighbours (g : 'a graph) (vertex : 'a) =
  (let f a l = let (x, y, w) = a in if x = vertex then (y, w) :: l else l in
   List.fold_right f g.edges [] : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (x, w) = node in
      if x = b
      then (visited, w)
      else
        (let nodes =
           List.map (fun n -> let (a, b) = n in (a, (b + w)))
             (neighbours g x) in
         aux_list nodes visited) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | (y, w)::xs ->
          if List.exists (fun node -> node = y) visited
          then aux_list xs visited
          else
            (try aux_node (y, w) (visited @ [y])
             with | Fail -> aux_list xs visited)
      | [] -> raise Fail : ('a list * weight)) in
   aux_node (a, 0) [a] : ('a list * weight))
