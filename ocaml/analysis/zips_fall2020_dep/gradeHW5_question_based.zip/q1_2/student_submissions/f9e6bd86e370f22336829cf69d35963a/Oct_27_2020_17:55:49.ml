let neighbours (g : 'a graph) (vertex : 'a) =
  (let f a l =
     match a with | (x, y, w) -> if x = vertex then (y, w) :: l else l in
   List.fold_right f g.edges [] : ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (match node with
      | (x, w) ->
          if x = b
          then (visited, w)
          else (let nodes = neighbours g x in aux_list nodes visited) : 
     ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | (y, w)::xs ->
          if List.exists (fun node -> node = y) visited
          then aux_list xs visited
          else
            (try aux_node (y, w) (y :: visited)
             with | Fail -> aux_list xs visited)
      | [] -> raise Fail : ('a list * weight)) in
   aux_node (a, 0) [a] : ('a list * weight))
