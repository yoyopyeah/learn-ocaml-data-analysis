let neighbours (g : 'a graph) (vertex : 'a) =
  (let edge acc x (a, b, c) = if a = x then [(b, c)] else acc in
   List.fold_left (fun x -> fun y -> (edge [] vertex y) @ x) [] g.edges : 
  ('a * weight) list)
let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec check_exist (a, b) visited =
     match visited with
     | [] -> false
     | x::xs -> if x = a then true else check_exist (a, b) xs in
   let rec aux_node (node : ('a * weight)) (visited : 'a list) money =
     (if check_exist node visited
      then raise Fail
      else
        (let (a, c) = node in
         if a = b
         then ((visited @ [a]), (money + c))
         else aux_list (neighbours g a) (visited @ [a]) c) : ('a list *
                                                               weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) money =
     (match nodes with
      | [] -> raise Fail
      | x::xs ->
          (try aux_node x visited money
           with | Fail -> aux_list xs visited money) : ('a list * weight)) in
   aux_node (a, 0) [] 0 : ('a list * weight))
