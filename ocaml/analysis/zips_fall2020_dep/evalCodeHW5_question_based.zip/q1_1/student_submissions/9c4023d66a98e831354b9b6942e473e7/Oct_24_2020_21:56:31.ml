let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = []; edges = [] } "0") [];
  ({ nodes = ["1"; "2"]; edges = ["1" "2" 5; "2" "1" 10] } "2") ["1" 10]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (let check_edge (e : ('a * 'a * weight)) =
     let e = (n1 * n2) * w in n1 == vertex in
   List.fold_right (fun x -> fun l -> if check_edge x then x :: l else l)
     g.edges [] : ('a * weight) list)
