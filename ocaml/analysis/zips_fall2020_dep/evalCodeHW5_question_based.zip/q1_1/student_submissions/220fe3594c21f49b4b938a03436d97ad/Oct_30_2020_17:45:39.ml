let g =
  {
    nodes = ["Toronto"; "Vancouver"; "Ottawa"];
    edges = ["Ottawa" "Toronto" 2; "Toronto" "Vancouver" 1]
  }
let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(g "Ottawa") ("Toronto" 2)]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
