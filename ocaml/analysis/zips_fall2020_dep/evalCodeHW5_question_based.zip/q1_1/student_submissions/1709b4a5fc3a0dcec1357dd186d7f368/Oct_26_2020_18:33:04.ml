let graph1 = { nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 2; "b" "a" 3] }
let graph2 =
  { nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 2; "b" "a" 3; "a" "c" 2] }
let graph3 = { nodes = []; edges = [] }
let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(graph1 "a") ["b" 2]; (graph2 "a") ["b" 2; "c" 2]; (graph3 "a") Fail]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
