let graph1 = { nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 2; "b" "a" 3] }
let graph2 =
  { nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 2; "b" "a" 3; "a" "c" 2] }
let graph3 = { nodes = []; edges = [] }
let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(graph1 "a") ["b" 2]; (graph2 "a") ["b" 2; "c" 2]; (graph3 "a") []]
let neighbours (g : 'a graph) (vertex : 'a) =
  (let catcher result edge =
     let edge = v1 v2 weight in
     if v1 = vertex then result :: (v2 weight) else result in
   List.fold_left [] g.egdes : ('a * weight) list)
