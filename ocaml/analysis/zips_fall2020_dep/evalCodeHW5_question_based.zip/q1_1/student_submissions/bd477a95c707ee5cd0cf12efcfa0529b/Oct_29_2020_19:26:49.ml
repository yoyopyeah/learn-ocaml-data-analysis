let neighbours_tests
  : ((string graph * string) * (string * weight) list) list = []
