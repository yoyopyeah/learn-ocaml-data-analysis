let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = [1; 2]; edges = [1 2 5] } 1) (2 5)]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
