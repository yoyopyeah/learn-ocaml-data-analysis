let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["1"; "2"]; edges = ["1" "2" 5] } "1") ["2" 5];
  ({ nodes = ["1"; "2"; "3"]; edges = [("1" "2" 5) ("2" "3" 5)] } "2")
    ["3" 5]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
