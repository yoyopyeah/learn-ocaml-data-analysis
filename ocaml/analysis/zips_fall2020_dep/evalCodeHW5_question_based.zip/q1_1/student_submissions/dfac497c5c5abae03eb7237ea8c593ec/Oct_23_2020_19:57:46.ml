let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 3; "a" "c" 6; "a" "d" 4]
    } "a") ["b" 3; "c" 6; "d" 4]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
