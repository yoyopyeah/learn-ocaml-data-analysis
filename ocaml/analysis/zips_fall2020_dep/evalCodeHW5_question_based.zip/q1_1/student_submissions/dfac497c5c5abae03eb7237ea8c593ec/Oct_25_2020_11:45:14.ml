let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["a"; "b"]; edges = ["a" "b" 3] } "a") ["b" 3];
  ({ nodes = []; edges = [] } "a") []]
let neighbours (g : 'a graph) (vertex : 'a) =
  (List.fold_right (fun x -> fun y -> if x = (vertex b w) then x :: y)
     g.edges [] : ('a * weight) list)
