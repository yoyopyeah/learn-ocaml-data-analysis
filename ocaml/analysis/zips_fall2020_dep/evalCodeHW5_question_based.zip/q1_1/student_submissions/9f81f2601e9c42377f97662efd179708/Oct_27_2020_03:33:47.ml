let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["a"; "b"; "c"]; edges = ["a" "b" 1; "b" "c" 3] } "a") ["b" 1]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
