let test_graph =
  { nodes = ["a"; "b"; "c"; "d"]; edges = ["a" "b" 1; "a" "c" 1; "b" "d" 1] }
let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(test_graph "a") ["b" 1; "c" 1]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
