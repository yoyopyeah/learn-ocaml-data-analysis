let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(map "a") ["b" 10; "c" 5; "d" 3]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
