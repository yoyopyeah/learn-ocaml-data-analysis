let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = [a; b; c; d]; edges = [a b 4; a c 1; d a 1; c b 2] } a) []]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
