let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({
      nodes = ["art"; "pie"; "user"; "lab"];
      edges = ["pie" "user" 6; "user" "art" 2]
    } "lab") [];
  ({
     nodes = ["art"; "pie"; "user"; "lab"];
     edges = ["pie" "user" 6; "user" "art" 2]
   } "user") ["art" 2];
  ({
     nodes = ["art"; "pie"; "user"; "lab"];
     edges = ["pie" "user" 6; "user" "art" 2]
   } "art") [];
  ({
     nodes = ["art"; "pie"; "user"; "lab"];
     edges = ["pie" "user" 6; "user" "art" 2; "user" "lab" 4]
   } "user") ["art" 2; "lab" 4]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
