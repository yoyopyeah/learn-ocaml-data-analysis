let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({
      nodes = ["art"; "pie"; "user"; "lab"];
      edges = ["pie" "user" 6; "user" "art" 2]
    } "user") ["art" 2]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
