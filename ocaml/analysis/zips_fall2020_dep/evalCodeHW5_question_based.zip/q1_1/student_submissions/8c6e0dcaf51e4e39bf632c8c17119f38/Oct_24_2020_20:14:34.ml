let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(let g =
      {
        nodes = ["art"; "pie"; "user"; "lab"];
        edges = ["pie" "user" 6; "user" "art" 2]
      } in
    (g "user") ["art" 2])]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
