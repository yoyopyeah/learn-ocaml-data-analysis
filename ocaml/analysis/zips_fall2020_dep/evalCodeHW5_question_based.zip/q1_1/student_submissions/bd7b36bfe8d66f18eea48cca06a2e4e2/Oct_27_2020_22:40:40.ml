let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["city"; "palce"]; edges = ["city" "place" 2] } "city")
     ["place" 2];
  ({ nodes = ["a"]; edges = ["a" "a1" 2] } "a") ["a1" 2]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
