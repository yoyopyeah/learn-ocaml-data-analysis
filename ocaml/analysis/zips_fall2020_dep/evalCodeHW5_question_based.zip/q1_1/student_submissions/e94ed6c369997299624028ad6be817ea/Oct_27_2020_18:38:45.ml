let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["2"; "3"; "4"]; edges = ["2" "3" 1; "2" "4" 3] } "2")
     ["3" 1; "4" 3];
  ({ nodes = ["2"; "3"]; edges = ["2" "3" 1] } "2") ["3" 1];
  ({ nodes = ["2"; "3"; "1"]; edges = [] } "2") [];
  ({ nodes = []; edges = [] } "2") []]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
