let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(graph (["2"; "3"] ["2" "3" 1]) "2") ["3" "1"]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
