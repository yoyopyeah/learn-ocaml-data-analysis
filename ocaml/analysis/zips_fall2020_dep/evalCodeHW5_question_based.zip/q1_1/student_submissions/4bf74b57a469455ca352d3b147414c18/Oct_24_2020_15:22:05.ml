let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["1"; "2"; "3"]; edges = ["1" "2" 10; "1" "3" 9] } "1")
     ["2" 10; "3" 9]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
