let g =
  {
    nodes = ['a'; 'b'; 'c'; 'd'; 'e'; 'f'];
    edges = ['a' 'b' 1; 'a' 'c' 2; 'c' 'd' 3; 'd' 'f' 4; 'c' 'f' 5]
  }
let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [(g 'a') ['b' 1; 'c' 2]]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
