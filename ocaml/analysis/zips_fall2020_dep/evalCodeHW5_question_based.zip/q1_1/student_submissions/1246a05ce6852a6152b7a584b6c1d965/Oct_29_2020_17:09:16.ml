let neighbours_tests
  : ((string graph * string) * (string * weight) list) list = []
let neighbours (g : 'a graph) (vertex : 'a) =
  (match g with | a -> a weight 1 : ('a * weight) list)
