let neighbours_tests
  : ((string graph * string) * (string * weight) list) list =
  [({ nodes = ["a"; "b"; "c"]; edges = ["a" "b" 1; "b" "c" 2; "a" "c" 3] }
      "a") ["b" 1; "c" 3];
  ({ nodes = ["a"; "b"; "c"]; edges = ["b" "c" 1; "c" "b" 2; "c" "a" 3] } "a")
    []]
let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
