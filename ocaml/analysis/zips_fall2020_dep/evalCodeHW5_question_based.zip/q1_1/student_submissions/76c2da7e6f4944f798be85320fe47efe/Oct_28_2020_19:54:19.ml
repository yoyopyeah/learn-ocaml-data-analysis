let neighbours_tests
  : ((string graph * string) * (string * weight) list) list = []
let neighbours (g : 'a graph) (vertex : 'a) =
  (List.iter (fun item -> if item = vertex then o w) g.edges : ('a * weight)
                                                                 list)
