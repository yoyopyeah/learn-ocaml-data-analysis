let neighbours_tests
  : ((string graph * string) * (string * weight) list) list = []
let neighbours (g : 'a graph) (vertex : 'a) =
  (let rec nei g vertex =
     match g with
     | [] -> []
     | a::tl -> if a == vertex then a :: (nei tl vertex) in
   nei g.nodes vertex : ('a * weight) list)
