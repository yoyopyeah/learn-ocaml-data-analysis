let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (raise NotImplemented : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (raise NotImplemented : ('a list * weight)) in
   raise NotImplemented : ('a list * weight))
