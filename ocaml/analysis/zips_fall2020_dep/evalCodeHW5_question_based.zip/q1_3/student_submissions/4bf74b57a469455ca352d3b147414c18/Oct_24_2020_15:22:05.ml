let find_path' (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited fc sc = raise NotImplemented
   and aux_list nodes visited fc sc = raise NotImplemented in
   raise NotImplemented : ('a list * weight))
