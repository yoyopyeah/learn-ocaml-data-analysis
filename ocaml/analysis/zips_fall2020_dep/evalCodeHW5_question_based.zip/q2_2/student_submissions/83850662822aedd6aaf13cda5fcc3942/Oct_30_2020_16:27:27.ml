let rec merge (s1 : 'a str) (s2 : 'a str) =
  ({
     hd = (if s1.hd < s2.hd then s1.hd else s2.hd);
     tl =
       (Susp
          (fun () ->
             if s1.hd < s2.hd
             then merge (force s1.tl) s2
             else
               if s1.hd = s2.hd
               then merge (force s1.tl) (force s2.tl)
               else merge s1 (force s2.tl)))
   } : 'a str)
let rec hamming_series =
  let rec power_series n k =
    { hd = n; tl = (Susp (fun () -> power_series (n * k) k)) } in
  merge (merge (power_series 1 2) (power_series 1 3)) (power_series 1 5)
