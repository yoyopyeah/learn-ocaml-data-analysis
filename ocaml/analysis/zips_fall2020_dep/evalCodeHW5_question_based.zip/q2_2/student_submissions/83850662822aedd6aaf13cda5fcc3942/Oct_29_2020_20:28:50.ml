let rec merge (s1 : 'a str) (s2 : 'a str) =
  ({
     hd = (if s1.hd < s2.hd then s1.hd else s2.hd);
     tl =
       (Susp
          (fun () ->
             if s1.hd < s2.hd
             then merge (force s1.tl) s2
             else merge s1 (force s2.tl)))
   } : 'a str)
let rec hamming_series =
  let rec numsFrom n = { hd = n; tl = (Susp (fun () -> numsFrom (n + 1))) } in
  let nats = numsFrom 0 in
  merge (merge ((times 2) nats) ((times 2) nats)) ((times 5) nats)
