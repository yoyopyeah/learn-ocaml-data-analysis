let rec hamming_series = raise NotImplemented
