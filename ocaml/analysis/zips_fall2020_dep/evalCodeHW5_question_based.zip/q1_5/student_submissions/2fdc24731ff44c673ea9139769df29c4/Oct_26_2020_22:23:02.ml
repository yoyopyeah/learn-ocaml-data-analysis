let find_shortest_path (g : 'a graph) (a : 'a) (b : 'a) =
  (raise NotImplemented : ('a list * weight) option)
