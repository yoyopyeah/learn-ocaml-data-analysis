let eval e = eval' (parse e)
