let neighbours (g : 'a graph) (vertex : 'a) =
  (List.iter (fun item -> if item = vertex then [o w]) g.edges : ('a *
                                                                   weight)
                                                                   list)
