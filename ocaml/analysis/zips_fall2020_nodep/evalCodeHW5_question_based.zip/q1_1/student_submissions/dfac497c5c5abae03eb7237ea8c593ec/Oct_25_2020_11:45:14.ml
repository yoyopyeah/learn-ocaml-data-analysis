let neighbours (g : 'a graph) (vertex : 'a) =
  (List.fold_right (fun x -> fun y -> if x = (vertex b w) then x :: y)
     g.edges [] : ('a * weight) list)
