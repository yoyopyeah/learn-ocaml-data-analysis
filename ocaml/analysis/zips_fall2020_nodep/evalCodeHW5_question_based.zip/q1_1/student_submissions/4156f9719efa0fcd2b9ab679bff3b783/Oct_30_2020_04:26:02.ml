let neighbours (g : 'a graph) (vertex : 'a) =
  (let neighbour l n = match n with | _ -> l in
   List.fold_left neighbour [] g.edges : ('a * weight) list)
