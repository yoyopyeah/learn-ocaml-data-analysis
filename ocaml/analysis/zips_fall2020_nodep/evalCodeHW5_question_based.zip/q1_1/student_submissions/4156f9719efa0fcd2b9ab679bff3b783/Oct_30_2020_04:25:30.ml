let neighbours (g : 'a graph) (vertex : 'a) =
  (let neighbour l n = l in List.fold_left neighbour [] g.edges : ('a *
                                                                    weight)
                                                                    list)
