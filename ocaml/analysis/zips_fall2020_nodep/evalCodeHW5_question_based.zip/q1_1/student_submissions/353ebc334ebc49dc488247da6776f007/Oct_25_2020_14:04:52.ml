let neighbours (g : 'a graph) (vertex : 'a) =
  (List.fold_left (::) [] g.edges : ('a * weight) list)
