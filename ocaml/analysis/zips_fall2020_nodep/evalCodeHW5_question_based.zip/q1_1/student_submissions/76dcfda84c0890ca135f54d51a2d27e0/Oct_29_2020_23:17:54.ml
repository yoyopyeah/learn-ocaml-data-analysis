let neighbours (g : 'a graph) (vertex : 'a) =
  (List.fold_right
     (fun g -> fun a -> if g.edges == ((a * a1) * w) then [[g.edges]]) g a : 
  ('a * weight) list)
