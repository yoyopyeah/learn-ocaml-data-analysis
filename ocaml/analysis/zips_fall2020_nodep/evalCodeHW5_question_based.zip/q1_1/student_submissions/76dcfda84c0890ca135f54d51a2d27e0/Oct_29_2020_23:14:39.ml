let neighbours (g : 'a graph) (vertex : 'a) =
  (List.fold_right
     (fun g -> fun a -> match g.edges with | a1 -> if a1 == a then [a1 * w])
     g a : ('a * weight) list)
