let neighbours (g : 'a graph) (vertex : 'a) =
  (let rec nei g vertex =
     match g with
     | [] -> []
     | a::tl -> if a == vertex then a :: (nei tl vertex) else [] in
   nei g.nodes vertex : ('a * weight) list)
