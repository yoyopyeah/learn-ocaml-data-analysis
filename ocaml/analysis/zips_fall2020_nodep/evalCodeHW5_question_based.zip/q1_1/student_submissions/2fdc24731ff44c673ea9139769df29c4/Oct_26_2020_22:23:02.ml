let neighbours (g : 'a graph) (vertex : 'a) =
  (raise NotImplemented : ('a * weight) list)
