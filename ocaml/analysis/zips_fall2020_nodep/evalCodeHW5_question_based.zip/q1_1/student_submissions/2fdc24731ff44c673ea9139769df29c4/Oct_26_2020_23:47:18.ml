let neighbours (g : 'a graph) (vertex : 'a) =
  (infindv g.edges vertex [] : ('a * weight) list)
