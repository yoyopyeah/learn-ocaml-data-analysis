let neighbours (g : 'a graph) (vertex : 'a) =
  (match g with | a -> a weight 1 : ('a * weight) list)
