let neighbours (g : 'a graph) (vertex : 'a) =
  (let catcher result edge =
     let edge = v1 v2 weight in
     if v1 = vertex then result :: (v2 weight) else result in
   List.fold_left [] g.egdes : ('a * weight) list)
