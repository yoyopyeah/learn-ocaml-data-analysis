let rec hamming_series = raise NotImplementedl
