let rec merge (s1 : 'a str) (s2 : 'a str) =
  (if s1.hd < s2.hd
   then { hd = (s1.hd); tl = (merge (force s1.tl) s2) }
   else
     if s1.hd > s2.hd
     then { hd = (s2.hd); tl = (merge s1 (force s2.tl)) }
     else { hd = (s1.hd); tl = (merge (force s1.tl) (force s2.tl)) } : 
  'a str)
