let rec merge (s1 : 'a str) (s2 : 'a str) = (raise NotImplemented : 'a str)
