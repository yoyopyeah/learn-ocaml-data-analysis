let find_all_paths (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (raise NotImplemented : ('a list * weight) list)
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (raise NotImplemented : ('a list * weight) list) in
   raise NotImplemented : ('a list * weight) list)
