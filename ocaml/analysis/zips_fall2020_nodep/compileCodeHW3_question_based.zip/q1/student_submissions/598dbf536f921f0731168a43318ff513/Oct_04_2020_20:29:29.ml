let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (((fun x -> x)) 2) [0; 1; 2];
  (((fun x -> x)) 0) [0]]
