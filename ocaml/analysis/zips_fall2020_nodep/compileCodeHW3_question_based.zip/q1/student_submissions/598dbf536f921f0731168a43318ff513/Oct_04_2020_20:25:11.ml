let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (tabulate (fun x -> dist_black 2 2 (x 2)) 6) [0. 0 0.2 0.45 0.6 0.5 0.]]
