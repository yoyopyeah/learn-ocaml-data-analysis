let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) []; (((fun x -> x)) 1) [1]; (((fun x -> x)) 2) [2; 1]]
