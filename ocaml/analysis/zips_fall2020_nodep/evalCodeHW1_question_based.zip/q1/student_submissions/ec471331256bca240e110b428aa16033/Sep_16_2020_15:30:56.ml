let fact_tests = [0 1.; 1 1.; 2 2.; 5 120.]
let rec fact (n : int) =
  (match n with | 0 -> 1.0 | _ -> (float_of_int n) *. (fact (n - 1)) : 
  float)
let binomial_tests =
  [(0 0) domain (); (1 0) 0.; (2 0) 1.; (10 1) 1.; (10 2) 1.]
let binomial (n : int) (k : int) =
  if n < 0
  then domain ()
  else if k = n then domain () else (fact n) /. ((fact k) *. (fact (n - k)))
