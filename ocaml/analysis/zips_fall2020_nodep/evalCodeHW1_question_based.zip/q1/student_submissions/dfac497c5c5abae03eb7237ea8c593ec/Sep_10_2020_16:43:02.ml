let fact n =
  let rec f n acc = if n = 0 then 1 else (f (n - 1) acc) * n in
  if n < 0 then raise Domain else f n 1
