let rec fact (n : int) =
  (match n with
   | 0 -> 1.0
   | _ -> float_of_int (n * (int_of_float (fact (n - 1)))) : float)
