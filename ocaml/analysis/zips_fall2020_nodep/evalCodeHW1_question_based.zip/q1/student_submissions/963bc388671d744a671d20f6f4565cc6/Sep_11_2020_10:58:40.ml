let fact_tests = [0 1.; 1 1.; 2 2.; 5 120.]
let fact (n : int) =
  (let rec fact_in (n : float) =
     (match n with | 0.0 -> 1.0 | _ -> n *. (fact_in (n -. 1.0)) : float) in
   fact_in (float_of_int n) : float)
