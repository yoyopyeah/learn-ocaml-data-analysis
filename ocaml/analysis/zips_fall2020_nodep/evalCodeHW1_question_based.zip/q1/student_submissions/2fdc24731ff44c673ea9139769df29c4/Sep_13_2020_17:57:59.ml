let rec fact n = if n = 0 then 1 else n * (fact (n - 1))
exception Domain 
let rec fact n =
  if n < 0 then raise Domain else if n = 0 then 1 else n * (fact (n - 1))
let rec fact n =
  let rec f n = if n = 0 then 1 else n * (f (n - 1)) in
  if n < 0 then raise Domain else f n
