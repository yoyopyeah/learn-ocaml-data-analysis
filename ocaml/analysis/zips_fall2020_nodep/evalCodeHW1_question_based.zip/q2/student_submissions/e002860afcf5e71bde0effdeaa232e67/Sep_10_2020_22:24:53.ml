let is_prime_tests = [2 true; 3 true; 255 false; 1307 true]
let is_prime n =
  if n < 2
  then domain ()
  else
    (let rec naive (x : int) =
       (if (x * x) <= n
        then (if (n mod x) = 0 then false else naive (x + 1))
        else true : bool) in
     naive 2)
