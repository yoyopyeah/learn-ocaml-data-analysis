(* The code here will be added to the top of your code automatically.
   You do NOT need to copy it into your code if you use LearnOCaml.
*)

exception NotImplemented
let domain () =
    failwith "REMINDER: You should not be writing tests for undefined values."
