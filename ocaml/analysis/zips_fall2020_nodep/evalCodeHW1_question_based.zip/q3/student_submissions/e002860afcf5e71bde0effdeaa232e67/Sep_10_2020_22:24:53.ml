let square_root_tests = []
let square_root a =
  let rec findroot x acc = raise NotImplemented in
  if a > 0.0 then findroot 1.0 epsilon_float else domain ()
