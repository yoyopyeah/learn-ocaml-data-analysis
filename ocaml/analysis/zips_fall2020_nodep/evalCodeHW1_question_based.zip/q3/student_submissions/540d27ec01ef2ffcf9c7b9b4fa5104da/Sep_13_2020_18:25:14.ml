let square_root a =
  let rec findroot x acc =
    let x' = ((a /. x) +. x) /. 2.0 in
    if (abs (x -. x')) < acc then x' else findroot x' acc in
  if a > 0.0 then findroot 1.0 epsilon_float else domain ()
