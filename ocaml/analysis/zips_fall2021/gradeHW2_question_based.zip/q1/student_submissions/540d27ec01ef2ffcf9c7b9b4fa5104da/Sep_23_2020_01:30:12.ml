let compress_tests =
  [([A; A; C; C; T; T; G; G], [(2, A); (2, C); (2, T); (2, G)]);
  ([A; T; A; T; G; G; G; G; G; G; G],
    [(1, A); (1, T); (1, A); (1, T); (7, G)]);
  ([], []);
  ([C], [(1, C)]);
  ([T; T; T; T; T; T; T; T; T; T; A], [(10, T); (1, A)]);
  ([T; T; T; T; T; T; T; T; T; T], [(10, T)])]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [([(2, A); (2, C); (2, T); (2, G)], [A; A; C; C; T; T; G; G]);
  ([(1, A); (1, T); (1, A); (1, T); (7, G)],
    [A; T; A; T; G; G; G; G; G; G; G]);
  ([], []);
  ([(1, C)], [C]);
  ([(10, T); (1, A)], [T; T; T; T; T; T; T; T; T; T; A]);
  ([(10, T)], [T; T; T; T; T; T; T; T; T; T])]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
