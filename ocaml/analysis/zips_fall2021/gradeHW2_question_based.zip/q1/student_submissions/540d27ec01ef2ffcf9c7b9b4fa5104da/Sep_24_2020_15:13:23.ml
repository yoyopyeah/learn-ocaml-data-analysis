let compress_tests =
  [([A; A; C; C; T; T; G; G], [(2, A); (2, C); (2, T); (2, G)]);
  ([A; T; A; T; G; G; G; G; G; G; G],
    [(1, A); (1, T); (1, A); (1, T); (7, G)]);
  ([], []);
  ([C], [(1, C)]);
  ([T; T; T; T; T; T; T; T; T; T; A], [(10, T); (1, A)]);
  ([T; T; T; T; T; T; T; T; T; T], [(10, T)])]
let compress (l : nucleobase list) =
  (let rec storeBase (acc : int) (base : nucleobase)
     (input : nucleobase list) (output : (int * nucleobase) list) =
     match input with
     | [] -> output @ [(acc, base)]
     | head::tail ->
         if head = base
         then storeBase (acc + 1) base tail output
         else storeBase 1 head tail (output @ [(acc, base)]) in
   match l with | [] -> [] | h::t -> storeBase 1 h t [] : (int * nucleobase)
                                                            list)
let decompress_tests =
  [([(2, A); (2, C); (2, T); (2, G)], [A; A; C; C; T; T; G; G]);
  ([(1, A); (1, T); (1, A); (1, T); (7, G)],
    [A; T; A; T; G; G; G; G; G; G; G]);
  ([], []);
  ([(1, C)], [C]);
  ([(10, T); (1, A)], [T; T; T; T; T; T; T; T; T; T; A]);
  ([(10, T)], [T; T; T; T; T; T; T; T; T; T])]
let rec decompress (l : (int * nucleobase) list) =
  (let rec iterateBase (acc : int) (base : nucleobase)
     (sublist : nucleobase list) =
     (if acc = 0
      then sublist
      else iterateBase (acc - 1) base (base :: sublist) : nucleobase list) in
   match l with
   | [] -> []
   | h::t -> let (i, b) = h in (iterateBase i b []) @ (decompress t) : 
  nucleobase list)
