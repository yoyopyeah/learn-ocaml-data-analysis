let compress_tests =
  [([], []);
  ([T], [(1, T)]);
  ([T; A; C; G], [(1, T); (1, A); (1, C); (1, G)]);
  ([A; A; C; C; G; G; T; T], [(2, A); (2, C); (2, G); (2, T)])]
let compress (l : nucleobase list) =
  (let rec split (l : nucleobase list) (count : int) (nucleo : nucleobase)
     (list : (int * nucleobase) list) =
     (match l with
      | [] -> if count > 0 then list @ [(count, nucleo)] else list
      | x::l ->
          if x = nucleo
          then split l (count + 1) nucleo list
          else
            if count > 0
            then split l 1 x (list @ [(count, nucleo)])
            else split l 1 x list : (int * nucleobase) list) in
   split l 0 T [] : (int * nucleobase) list)
let decompress_tests =
  [([], []);
  ([(1, T)], [T]);
  ([(1, T); (1, A); (1, C); (1, G)], [T; A; C; G]);
  ([(2, A); (2, C); (2, G); (2, T)], [A; A; C; C; G; G; T; T])]
let rec decompress (l : (int * nucleobase) list) =
  (match l with
   | [] -> []
   | x::l ->
       (match x with
        | (1, n) -> n :: (decompress l)
        | (i, n) -> n :: (decompress (((i - 1), n) :: l))) : nucleobase list)
