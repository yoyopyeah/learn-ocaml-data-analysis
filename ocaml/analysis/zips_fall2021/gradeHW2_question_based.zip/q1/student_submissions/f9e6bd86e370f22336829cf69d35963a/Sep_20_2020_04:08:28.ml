let compress_tests =
  [([], []);
  ([T], [(1, T)]);
  ([T; A; C; G], [(1, T); (1, A); (1, C); (1, G)]);
  ([A; A; C; C; G; G; T; T], [(2, A); (2, C); (2, G); (2, T)])]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
