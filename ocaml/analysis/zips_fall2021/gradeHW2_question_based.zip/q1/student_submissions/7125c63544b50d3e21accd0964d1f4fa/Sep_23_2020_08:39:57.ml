let compress_tests =
  [([(A, A, A, A)], [(4, A)]);
  ([(A, T, C, G)], [(1, A); (1, T); (1, C); (1, G)]);
  ([(T, T, T, T)], [(4, T)]);
  ([(A, A, T, T)], [(2, A); (2, T)]);
  ([(A, T, T, G)], [(1, A); (2, T); (1, G)])]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
