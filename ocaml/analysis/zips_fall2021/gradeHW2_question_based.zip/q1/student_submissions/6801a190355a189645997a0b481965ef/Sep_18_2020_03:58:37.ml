let compress_tests =
  [([A], [(1, A)]);
  ([A; A], [(2, A)]);
  ([A; A; C; T; T; T; T; G], [(2, A); (1, C); (4, T); (1, G)]);
  ([A; A; C; T; T; T; T; G; A; A; A],
    [(2, A); (1, C); (4, T); (1, G); (3, A)]);
  ([], [])]
let compress (l : nucleobase list) =
  (let rec compr (nucl : nucleobase) (qty : (int * nucleobase))
     (remain : nucleobase list) =
     let h::t = remain in
     if h = nucl
     then let (i, _) = qty in compr nucl ((i + 1), nucl) t
     else (remain, [qty]) in
   let rec iterate (tuple : (nucleobase list * (int * nucleobase) list)) =
     match tuple with
     | ([], ret) -> ret
     | (h::t, ret) -> ret @ (iterate (compr h (1, h) t)) in
   match l with | [] -> [] | h::_ -> iterate (l, []) : (int * nucleobase)
                                                         list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
