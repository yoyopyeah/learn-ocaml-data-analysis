let compress_tests =
  [(([A], [(1, A)]), ([A; A], [(2, A)]),
     ([A; A; C; T; T; T; T; G], [(2, A); (1, C); (4, T); (1, G)]))]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
