let compress_tests =
  [([A], [(1, A)]);
  ([A; A], [(2, A)]);
  ([A; A; C; T; T; T; T; G], [(2, A); (1, C); (4, T); (1, G)]);
  ([A; A; C; T; T; T; T; G; A; A; A],
    [(2, A); (1, C); (4, T); (1, G); (3, A)]);
  ([], [])]
let compress (l : nucleobase list) =
  (let rec compr (nucl : nucleobase) (qty : (int * nucleobase))
     (remain : nucleobase list) (ret : (int * nucleobase) list) =
     match remain with
     | [] -> ret
     | h::t ->
         if h = nucl
         then (match qty with | (i, _) -> compr nucl ((i + 1), nucl) t ret)
         else ret @ (compr h (0, h) t ret) in
   match l with | [] -> [] | h::t -> compr h (1, h) t [] : (int * nucleobase)
                                                             list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
