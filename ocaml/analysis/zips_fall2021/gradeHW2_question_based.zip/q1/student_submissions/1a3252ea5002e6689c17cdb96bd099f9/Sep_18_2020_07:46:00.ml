let compress_tests = [(([A], [(1, A)]), ([], []), ([A; A], [(2, A)]))]
let compress (l : nucleobase list) =
  (let rec aux count acc =
     function
     | [] -> []
     | x::[] -> ((count + 1), x) :: acc
     | a::(b::_ as t) ->
         if a = b
         then aux (count + 1) acc t
         else aux 0 (((count + 1), a) :: acc) t in
   List.rev (aux 0 [] (l : nucleobase list)) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
