let compress_tests =
  [(([A], [(1, A)]), ([], []), ([A; A; A], [(4, A)]),
     ([A; A; A; G; G; A; T; T; C; T],
       [(3, A); (2, G); (1, A); (2, T); (1, C); (1, T)]),
     ([A; A; A; A; A; G; G; A; T; T; T; C; T; C; C],
       [(5, A); (2, G); (1, A); (3, T); (1, C); (1, T); (2, C)]),
     ([A; A; A; A; T; T; T; C; T; C],
       [(4, A); (3, T); (1, C); (1, T); (1, C)]),
     ([A; A; A; A; G; G; A; C; T; C],
       [(4, A); (2, G); (1, A); (1, C); (1, T); (1, C)]))]
let compress (l : nucleobase list) =
  (let rec func list count acc =
     match list with
     | [] -> []
     | x::[] -> acc @ [(1, x)]
     | first::second::rest ->
         if first = second
         then func rest (count + 1) acc
         else (func rest 0 acc) @ [((count + 1), first)] in
   func (l : nucleobase list) 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
