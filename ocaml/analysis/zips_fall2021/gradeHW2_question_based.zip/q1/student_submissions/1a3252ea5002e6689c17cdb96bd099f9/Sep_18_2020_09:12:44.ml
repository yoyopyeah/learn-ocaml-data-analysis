let compress_tests =
  [(([], []), ([A], [(1, A)]), ([A; A; A], [(3, A)]),
     ([A; A; A; G; G; A; T; T; C; T],
       [(3, A); (2, G); (1, A); (2, T); (1, C); (1, T)]),
     ([A; A; A; A; A; G; G; A; T; T; T; C; T; C; C],
       [(5, A); (2, G); (1, A); (3, T); (1, C); (1, T); (2, C)]),
     ([A; A; A; A; T; T; T; C; T; C],
       [(4, A); (3, T); (1, C); (1, T); (1, C)]),
     ([A; A; A; A; G; G; A; C; T; C],
       [(4, A); (2, G); (1, A); (1, C); (1, T); (1, C)]))]
let compress (l : nucleobase list) =
  (let rec recursive count acc list =
     match list with
     | [] -> acc
     | x::[] -> acc @ [((count + 1), x)]
     | first::(second::_ as rest) ->
         if first == second
         then recursive (count + 1) acc rest
         else recursive 0 (((count + 1), first) :: acc) rest in
   recursive 0 [] (l : nucleobase list) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
