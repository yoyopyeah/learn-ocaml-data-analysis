let compress_tests = [(([], []), ([A], [(1, A)]))]
let compress (l : nucleobase list) =
  (let rec recursive count acc list =
     match list with
     | [] -> []
     | x::[] -> ((count + 1), x) :: acc
     | first::(second::_ as rest) ->
         if first = second
         then recursive (count + 1) acc rest
         else recursive 0 (((count + 1), first) :: acc) rest in
   List.rev (recursive 0 [] (l : nucleobase list)) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
