let compress_tests = [(([A], [(1, A)]), ([], []))]
let compress (l : nucleobase list) =
  (let rec recursive list count acc =
     match list with
     | [] -> []
     | x::[] -> [(1, x)]
     | a::(b::_ as t) ->
         if a = b
         then recursive t (count + 1) acc
         else recursive t 0 (((count + 1), a) :: acc) in
   recursive (l : nucleobase list) 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
