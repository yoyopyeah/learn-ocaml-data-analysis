let compress_tests =
  [(([], []), ([A], [(1, A)]), ([A; A; A], [(3, A)]),
     ([A; A; A; G; G; A; T; T; C; T],
       [(3, A); (2, G); (1, A); (2, T); (1, C); (1, T)]),
     ([A; A; A; A; A; G; G; A; T; T; T; C; T; C; C],
       [(5, A); (2, G); (1, A); (3, T); (1, C); (1, T); (2, C)]),
     ([A; A; A; A; T; T; T; C; T; C],
       [(4, A); (3, T); (1, C); (1, T); (1, C)]),
     ([A; A; A; A; G; G; A; C; T; C],
       [(4, A); (2, G); (1, A); (1, C); (1, T); (1, C)]))]
let compress (l : nucleobase list) =
  (let rec recursive count acc list =
     match list with
     | [] -> acc
     | x::[] -> acc @ [((count + 1), x)]
     | first::(second::_ as rest) ->
         if first == second
         then recursive (count + 1) acc rest
         else recursive 0 (acc @ [((count + 1), first)]) rest in
   recursive 0 [] l : (int * nucleobase) list)
let decompress_tests =
  [(([], []), ([(1, A)], [A]), ([(3, A)], [A; A; A]),
     ([(3, A); (2, G); (1, A); (2, T); (1, C); (1, T)],
       [A; A; A; G; G; A; T; T; C; T]))]
let rec decompress (l : (int * nucleobase) list) =
  (match l with
   | [] -> []
   | (0, _)::rest -> decompress rest
   | (n, c)::_ as rest -> c :: (decompress (((n - 1), c) :: rest)) : 
  nucleobase list)
