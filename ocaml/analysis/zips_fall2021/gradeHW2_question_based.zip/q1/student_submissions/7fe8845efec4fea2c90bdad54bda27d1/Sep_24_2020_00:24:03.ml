let compress_tests =
  [([], []);
  ([A], [(1, A)]);
  ([A; A; A; A; G; G; A; T; T; T; C; T; C],
    [(4, A); (2, G); (1, A); (3, T); (1, C); (1, T); (1, C)])]
let rec compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | x::t -> (match count 1 x t with | (n, l') -> (n, x) :: (compress l')) : 
  (int * nucleobase) list)
let decompress_tests =
  [([(4, A); (2, G); (1, A); (3, T); (1, C); (1, T); (1, C)],
     [A; A; A; A; G; G; A; T; T; T; C; T; C])]
let rec decompress (l : (int * nucleobase) list) =
  (match l with | [] -> [] | (n, s)::t -> (build n s) @ (decompress t) : 
  nucleobase list)
