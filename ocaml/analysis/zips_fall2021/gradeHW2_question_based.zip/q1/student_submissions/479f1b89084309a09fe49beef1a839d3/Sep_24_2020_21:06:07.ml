let compress_tests =
  [([A; G; C; T], [(1, A); (1, G); (1, C); (1, T)]);
  ([], []);
  ([A; A; A; G], [(3, A); (1, G)])]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
