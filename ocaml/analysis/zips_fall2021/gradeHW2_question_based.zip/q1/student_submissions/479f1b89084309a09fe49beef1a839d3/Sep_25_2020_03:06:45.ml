let compress_tests =
  [([A; G; C; T], [(1, A); (1, G); (1, C); (1, T)]);
  ([], []);
  ([A], [(1, A)]);
  ([A; A; G; A], [(2, A); (1, G); (1, A)])]
let decompress_tests =
  [([], []); ([(1, A)], [A]); ([(2, A); (1, G); (1, A)], [A; A; G; A])]
let decompress (l : (int * nucleobase) list) =
  (let rec f acc n x = if n = 0 then acc else f (x :: acc) (n - 1) x in
   let rec aux acc l =
     match l with | [] -> acc | (n, x)::xs -> aux (f acc n x) xs in
   aux [] (List.rev l) : nucleobase list)
