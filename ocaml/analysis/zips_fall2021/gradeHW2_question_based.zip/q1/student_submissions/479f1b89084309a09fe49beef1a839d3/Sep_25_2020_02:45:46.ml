let compress_tests =
  [([A; G; C; T], [(1, A); (1, G); (1, C); (1, T)]);
  ([], []);
  ([A], [(1, A)]);
  ([A; A; G; A], [(2, A); (1, G); (1, A)])]
let decompress_tests =
  [([], []); ([(1, A)], [A]); ([(2, A); (1, G); (1, A)], [A; A; G; A])]
