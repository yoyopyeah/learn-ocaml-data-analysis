let compress_tests =
  [([A; G; C; T], [(1, A); (1, G); (1, C); (1, T)]);
  ([], []);
  ([A], [(1, A)]);
  ([A; A; G; A], [(2, A); (1, G); (1, A)])]
let compress (l : nucleobase list) =
  (let rec comp_aux count l acc =
     match l with
     | [] -> acc
     | h::(hs::_ as t) ->
         if h = hs
         then comp_aux (count + 1) t acc
         else comp_aux 0 t (((count + 1), h) :: acc) in
   List.rev (comp_aux 0 l []) : (int * nucleobase) list)
let decompress_tests =
  [([], []); ([(1, A)], [A]); ([(2, A); (1, G); (1, A)], [A; A; G; A])]
let rec decompress (l : (int * nucleobase) list) =
  (raise Error : nucleobase list)
