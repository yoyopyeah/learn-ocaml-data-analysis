let compress_tests =
  [([], []);
  ([A], [(1, A)]);
  ([A; C], [(1, A); (1, C)]);
  ([A; A], [(2, A)]);
  ([A; A; A], [(3, A)]);
  ([A; A; A; T; T; G; C; C; C], [(3, A); (2, T); (1, G); (3, C)])]
let compress (l : nucleobase list) =
  (let rec compress' l count compressed_list =
     match l with
     | [] -> compressed_list
     | x::[] -> compressed_list @ [(count, x)]
     | base1::base2::tail ->
         if base1 = base2
         then compress' (base2 :: tail) (count + 1) compressed_list
         else
           compress' (base2 :: tail) 1 (compressed_list @ [(count, base1)]) in
   compress' l 1 [] : (int * nucleobase) list)
let decompress_tests =
  [([], []);
  ([(1, A)], [A]);
  ([(1, A); (1, C)], [A; C]);
  ([(2, A)], [A; A]);
  ([(3, A)], [A; A; A]);
  ([(3, A); (2, T); (1, G); (3, C)], [A; A; A; T; T; G; C; C; C])]
let rec decompress (l : (int * nucleobase) list) =
  (let rec decompress' l decompressed_list =
     match l with
     | [] -> decompressed_list
     | (i, base)::tail ->
         let rec repeat_append increment decompressed_list =
           if i > increment
           then repeat_append (increment + 1) (decompressed_list @ [base])
           else decompress' tail decompressed_list in
         repeat_append 0 decompressed_list in
   decompress' l [] : nucleobase list)
