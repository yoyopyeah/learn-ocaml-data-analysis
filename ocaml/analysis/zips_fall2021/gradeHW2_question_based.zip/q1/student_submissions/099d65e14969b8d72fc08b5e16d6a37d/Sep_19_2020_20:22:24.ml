let compress_tests =
  [([A], [(1, A)]);
  ([A; A], [(2, A)]);
  ([A; A; T; C; C; C; G; G; C], [(2, A); (1, T); (3, C); (2, G); (1, C)])]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
