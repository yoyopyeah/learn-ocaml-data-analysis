let compress_tests = [([A], [(1, A)]); ([A; A], [(2, A)]); ([], [])]
let rec compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | x::[] -> [(1, x)]
   | x::y::[] -> if x = y then [(2, x)] else [(1, x); (1, y)]
   | x::y::tail ->
       let rec loop (x::y::tail, z) =
         match (x, tail) with
         | (_, []) -> if x = y then [((z + 1), x)] else [(z, x); (1, y)]
         | (_, _) ->
             if x = y
             then loop ((y :: tail), (z + 1))
             else [(z, x)] @ (compress (y :: tail)) in
       loop ((x :: y :: tail), 1) : (int * nucleobase) list)
let decompress_tests =
  [([(4, A); (2, G); (1, A); (3, T); (1, C); (1, T); (1, C)],
     [A; A; A; A; G; G; A; T; T; T; C; T; C]);
  ([], []);
  ([(1, A)], [A])]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
