let rec map f l = match l with | [] -> [] | x::t -> (f x) :: (map f xs)
