let rec map l f = match l with | [] -> [] | h::t -> (f h) :: (map t f)
