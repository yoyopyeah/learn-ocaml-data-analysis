let rec map (f : 'a -> 'b) (l : 'a list) =
  (match l with | [] -> [] | x::xs -> (f x) :: (map f xs) : 'b list)
