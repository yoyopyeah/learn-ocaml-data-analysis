let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) []]
