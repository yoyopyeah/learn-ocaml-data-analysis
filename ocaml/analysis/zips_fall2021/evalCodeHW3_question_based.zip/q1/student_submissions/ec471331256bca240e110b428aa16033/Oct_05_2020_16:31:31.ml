let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) []; (((fun x -> 2 * x)) 3) [0; 1; 2; 3]]
