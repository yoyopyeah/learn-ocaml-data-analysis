let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (((fun x -> 2 * x)) 3) [0; 1; 2; 3];
  (((fun x -> true)) 3) [true; true; true; true];
  (((fun x -> "Hello")) 3) ["Hello"; "Hello"; "Hello"; "Hello"]]
