let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (((fun 2 -> 2)) 0) [2];
  (((fun x -> x * x)) 5) [];
  (((fun x -> x * x)) 7) []]
