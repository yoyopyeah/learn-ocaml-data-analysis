let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (((fun x -> x + x)) 0) [];
  (((fun x -> x * x)) 5) [];
  (((fun x -> x * x)) 7) []]
