let tabulate_tests : (((int -> int) * int) * int list) list =
  [((fun x -> x) - 1) [];
  (tabulate (dist 2 2 (6 2)) 6) [0. 0 0.2 0.45 0.6 0.5 0.]]
