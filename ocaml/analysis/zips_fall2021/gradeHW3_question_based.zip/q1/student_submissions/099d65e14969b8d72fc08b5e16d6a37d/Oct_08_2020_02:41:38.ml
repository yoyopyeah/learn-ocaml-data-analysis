let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), 0), [0]);
  ((((fun x -> x * 2)), 1), [0; 2]);
  ((((fun x -> x)), (-1)), [])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (tabulate (fun f -> dist_black f x (marblesTotal, marblesDrawn))
     marblesTotal : float list)
let is_empty_tests : (float list list * bool) list =
  [([[]], true); ([[]; []; []], true); ([[0.0]], false)]
let is_empty (matrix : 'a list list) =
  (List.for_all (fun x -> x == []) matrix : bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (List.map (fun x -> dist_table (total, drawn) x) resultList : float list
                                                                  list)
let rec combined_dist_table (matrix : float list list) =
  if is_empty matrix
  then []
  else
    (match matrix with
     | x::[] -> x
     | x::tail ->
         List.fold_left
           (fun x -> fun y -> List.map2 (fun a -> fun b -> a *. b) x y) x
           tail)
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
