let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), (-1)), []);
  ((((fun x -> x)), 2), [0; 1; 2]);
  ((((fun x -> 2)), 2), [2; 2; 2]);
  ((((fun x -> x)), 0), [0])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (let f n = dist_black n x (marblesTotal, marblesDrawn) in
   tabulate f marblesTotal : float list)
let is_empty_tests : (float list list * bool) list =
  [([[]; []; []], true); ([[]], true); ([[0.5; 0.1]; [0.2; 0.4]], false)]
let is_empty (matrix : 'a list list) =
  (let empty l = match l with | [] -> true | _::_ -> false in
   List.for_all empty matrix : bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (let f = dist_table (total, drawn) in List.map f resultList : float list
                                                                  list)
let rec combined_dist_table (matrix : float list list) =
  let f = ( *. ) in
  match is_empty matrix with
  | true -> []
  | false ->
      (match matrix with
       | x::[] -> x
       | x::y::ys -> combined_dist_table ((List.map2 f x y) :: ys))
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
