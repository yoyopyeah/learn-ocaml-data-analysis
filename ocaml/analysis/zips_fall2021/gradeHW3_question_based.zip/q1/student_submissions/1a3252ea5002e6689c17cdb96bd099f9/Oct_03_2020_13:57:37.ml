let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), (-1)), []);
  ((((fun x -> x)), 0), [0]);
  ((((fun x -> x)), 1), [0; 1]);
  ((((fun x -> x)), 2), [0; 1; 2])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (tabulate (fun y -> dist_black y x (marblesTotal, marblesDrawn))
     marblesTotal : float list)
let is_empty_tests : (float list list * bool) list =
  [([[0.; 0.; 0.2; 0.45; 0.6; 0.5; 0.];
    [1.; 0.5; 0.2; 0.05; 0.; 0.; 0.];
    [0.; 0.5; 0.6; 0.45; 0.2; 0.; 0.]], false);
  ([], true);
  ([[]], true);
  ([[]; []], true)]
let is_empty (matrix : 'a list list) =
  (List.for_all (fun x -> x != []) matrix : bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (raise NotImplemented : float list list)
let rec combined_dist_table (matrix : float list list) = raise NotImplemented
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
