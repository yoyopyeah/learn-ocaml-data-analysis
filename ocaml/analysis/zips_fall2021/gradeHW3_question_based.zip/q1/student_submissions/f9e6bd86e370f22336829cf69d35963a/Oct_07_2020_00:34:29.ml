let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), (-1)), []);
  ((fact, 5), [1; 1; 2; 6; 24; 120]);
  ((fact, 0), [1])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (let f mT mD xV n = dist_black n xV (mT, mD) in
   tabulate (f marblesTotal marblesDrawn x) marblesTotal : float list)
let is_empty_tests : (float list list * bool) list =
  [([], true);
  ([[]], true);
  ([[]; []], true);
  ([[1.; 2.; 3.]; []], false);
  ([[1.]], false)]
let is_empty (matrix : 'a list list) =
  (List.for_all (fun x -> (List.length x) = 0) matrix : bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (List.map (dist_table (total, drawn)) resultList : float list list)
let rec combined_dist_table (matrix : float list list) =
  let m x y = x *. y in
  List.fold_left (List.map2 m) (List.hd matrix) (List.tl matrix)
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
