let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), (-1)), []);
  ((((fun x -> x)), 0), [0]);
  ((((fun x -> x)), 3), [0; 1; 2; 3])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (tabulate (fun x -> dist_black marblesTotal x (marblesTotal, marblesDrawn))
     marblesTotal : float list)
let is_empty_tests : (float list list * bool) list =
  [([[]], true);
  ([[]; []], true);
  ([[]; []; []; []], true);
  ([[0.]], false);
  ([[0.; 2.; 3.]], false);
  ([[0.; 2.; 3.]; [1.; 2.; 3.]], false)]
let is_empty (matrix : 'a list list) =
  (let p e = match e with | [] -> true | _ -> false in List.for_all p matrix : 
  bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (List.map (fun resultList -> dist_table (total, drawn) resultList)
     resultList : float list list)
;;raise NotImplemented
let rec combined_dist_table (matrix : float list list) = raise NotImplemented
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
