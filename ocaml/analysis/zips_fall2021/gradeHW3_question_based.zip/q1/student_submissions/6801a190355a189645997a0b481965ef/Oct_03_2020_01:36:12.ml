let tabulate_tests : (((int -> int) * int) * int list) list =
  [((((fun x -> x)), (-1)), []);
  ((((fun x -> x)), 0), [0]);
  ((((fun x -> x + x)), 0), [0]);
  ((((fun x -> x + x)), 2), [0; 2; 4]);
  ((((fun x -> (x + 1) * x)), 3), [0; 2; 6; 12])]
let dist_table ((marblesTotal, marblesDrawn) : (int * int)) (x : int) =
  (raise NotImplemented : float list)
let is_empty_tests : (float list list * bool) list = []
let is_empty (matrix : 'a list list) = (raise NotImplemented : bool)
let dist_matrix ((total, drawn) : (int * int)) (resultList : int list) =
  (raise NotImplemented : float list list)
let rec combined_dist_table (matrix : float list list) = raise NotImplemented
let max_likelihood (total, drawn) resultList =
  max_in_list (combined_dist_table (dist_matrix (total, drawn) resultList))
