let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) (acc : weight)
     =
     (let (v, w) = node in
      if List.mem v visited
      then raise Fail
      else
        if v = b
        then ((visited @ [v]), (acc + w))
        else aux_list (neighbours g v) (visited @ [v]) (acc + w) : ('a list *
                                                                    weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list)
     (acc : weight) =
     (match nodes with
      | [] -> raise Fail
      | h::t ->
          (try aux_node h visited acc with | Fail -> aux_list t visited acc) : 
     ('a list * weight)) in
   aux_node (a, 0) [] 0 : ('a list * weight))
