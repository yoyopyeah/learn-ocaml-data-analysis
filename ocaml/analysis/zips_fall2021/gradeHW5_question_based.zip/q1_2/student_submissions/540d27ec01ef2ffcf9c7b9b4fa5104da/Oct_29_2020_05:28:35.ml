let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (x, w) = node in
      if List.mem x visited
      then raise Fail
      else
        if x = b
        then ((visited @ [x]), w)
        else aux_list (neighbours g x) (visited @ [x]) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | [] -> raise Fail
      | h::t -> (try aux_node h visited with | Fail -> aux_list t visited) : 
     ('a list * weight)) in
   aux_list (neighbours g a) [] : ('a list * weight))
