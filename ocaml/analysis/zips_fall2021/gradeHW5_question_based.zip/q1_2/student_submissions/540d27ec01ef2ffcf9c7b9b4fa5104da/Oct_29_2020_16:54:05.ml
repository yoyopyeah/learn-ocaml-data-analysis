let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list)
     (w_total : int) =
     (let (x, w) = node in
      if List.mem x visited
      then raise Fail
      else
        if x = b
        then ((visited @ [x]), (w_total + w))
        else aux_list (neighbours g x) (visited @ [x]) (w_total + w) : 
     ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list)
     (w_total : int) =
     (match nodes with
      | [] -> raise Fail
      | h::t ->
          (try aux_node h visited w_total
           with | Fail -> aux_list t visited w_total) : ('a list * weight)) in
   aux_list (neighbours g a) [a] 0 : ('a list * weight))
