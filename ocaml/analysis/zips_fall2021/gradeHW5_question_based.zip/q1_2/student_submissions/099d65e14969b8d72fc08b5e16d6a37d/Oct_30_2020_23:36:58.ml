let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited path weight =
     let (x, w) = node in
     if List.mem x visited
     then raise Fail
     else
       if x = b
       then ((b :: path), (weight + w))
       else
         (try aux_list (neighbours g x) visited (x :: path) (weight + w)
          with | Fail -> raise Fail)
   and aux_list nodes visited path weight =
     match nodes with
     | [] -> raise NotImplemented
     | (x, w)::xs ->
         (try aux_node (x, w) (x :: visited) path weight
          with | Fail -> aux_list xs (x :: visited) path weight) in
   match g with
   | { nodes = []; edges = _ } -> raise Fail
   | { nodes = _; edges = [] } -> raise Fail
   | { nodes = _; edges = _ } -> aux_list (neighbours g a) [] [] 0 : 
  ('a list * weight))
