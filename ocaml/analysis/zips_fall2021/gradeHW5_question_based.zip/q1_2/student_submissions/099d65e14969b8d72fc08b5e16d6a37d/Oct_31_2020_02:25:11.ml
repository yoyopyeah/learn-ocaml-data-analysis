let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited path weight =
     let (x, w) = node in
     if x = b
     then ((path @ [b]), (weight + w))
     else
       (try aux_list (neighbours g x) visited (path @ [x]) (weight + w)
        with | Fail -> raise Fail)
   and aux_list nodes visited path weight =
     match nodes with
     | [] -> raise Fail
     | (x, w)::xs ->
         if List.mem x visited
         then aux_list xs visited path weight
         else
           (try aux_node (x, w) (x :: visited) path weight
            with | Fail -> aux_list xs (x :: visited) path weight) in
   match g with
   | { nodes = []; edges = _ } -> raise Fail
   | { nodes = _; edges = [] } -> raise Fail
   | { nodes = _; edges = _ } -> aux_list (neighbours g a) [] [a] 0 : 
  ('a list * weight))
