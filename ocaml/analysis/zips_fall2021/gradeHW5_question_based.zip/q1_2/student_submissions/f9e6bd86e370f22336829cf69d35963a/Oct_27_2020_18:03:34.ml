let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (match node with
      | (x, w) ->
          if x = b
          then (visited, w)
          else (let nodes = neighbours g x in aux_list nodes visited) : 
     ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | (y, w)::xs ->
          if List.exists (fun node -> node = y) visited
          then aux_list xs visited
          else
            (try aux_node (y, w) (visited @ [y])
             with | Fail -> aux_list xs visited)
      | [] -> raise Fail : ('a list * weight)) in
   aux_node (a, 0) [a] : ('a list * weight))
