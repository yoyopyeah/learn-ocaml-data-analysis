let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node, weight) visited =
     if (List.mem (node, weight) visited) = true
     then raise Fail
     else
       (match (node, weight) with
        | (b, w) -> ((visited @ [(b, w)]), (weight + w))) in
   let rec aux_list nodes visited =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node (h, w) visited with | Fail -> aux_list t visited) in
   aux_list (neighbours g a) []; raise NotImplemented : ('a list * weight))
