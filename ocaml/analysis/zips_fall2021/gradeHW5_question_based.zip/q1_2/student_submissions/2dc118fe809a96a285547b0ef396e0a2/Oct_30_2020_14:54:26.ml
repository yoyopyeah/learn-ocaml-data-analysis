let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited weight =
     if List.mem node visited
     then raise Fail
     else (match node with | (b, w) -> (visited @ [(b, w)]; weight + w)) in
   let rec aux_list nodes visited weight =
     match nodes with
     | [] -> raise Fail
     | h::t ->
         (try aux_node h visited weight
          with | Fail -> aux_list t visited weight) in
   aux_list (neighbours g a) [] 0; raise NotImplemented : ('a list * weight))
