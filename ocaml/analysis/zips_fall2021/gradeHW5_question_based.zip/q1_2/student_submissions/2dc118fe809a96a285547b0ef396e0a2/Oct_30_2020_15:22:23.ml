let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited =
     if List.mem node visited
     then raise Fail
     else
       if node = b
       then visited @ [b]
       else aux_list (neighbours g node) (visited @ [b])
   and aux_list nodes visited =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node h visited with | Fail -> aux_list t visited) in
   aux_list (neighbours g a) []; raise NotImplemented : ('a list * weight))
