let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited weight =
     if List.mem node visited
     then raise Fail
     else
       if node = b
       then visited @ [b]
       else aux_list (neighbours g node) (visited @ [b]) weight
   and aux_list nodes visited weight =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node h visited weight
          with | Fail -> aux_list t visited weight) in
   aux_list (neighbours g a) [] 0; raise NotImplemented : ('a list * weight))
