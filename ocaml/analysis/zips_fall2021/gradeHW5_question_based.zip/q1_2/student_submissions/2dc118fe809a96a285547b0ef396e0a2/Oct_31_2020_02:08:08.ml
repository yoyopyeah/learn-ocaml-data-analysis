let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited =
     let (n, w) = node in
     if List.mem n visited
     then raise Fail
     else
       if n = b
       then ((visited @ [n]), w)
       else aux_list (neighbours g n) (visited @ [n]) w
   and aux_list nodes visited weight =
     match nodes with
     | [] -> raise Fail
     | h::t ->
         let (n, w) = h in
         (try aux_node (n, (weight + w)) visited
          with | Fail -> aux_list t visited weight) in
   aux_node (a, 0) [] : ('a list * weight))
