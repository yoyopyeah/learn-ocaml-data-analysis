let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node node visited = raise NotImplemented in
   raise NotImplemented raise NotImplemented : ('a list * weight))
