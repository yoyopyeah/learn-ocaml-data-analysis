let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let weight = 0 in
   let rec aux_node node visited =
     if (List.mem node visited) = true
     then raise Fail
     else
       (match node with
        | b -> raise Fail
        | (b, w) -> ((b, w) :: visited; weight + w)) in
   let rec aux_list nodes visited =
     match nodes with
     | [] -> raise Fail
     | (h, w)::t ->
         (try aux_node (h, w) visited with | Fail -> aux_list t visited) in
   let n = neighbours g a in aux_list n []; raise NotImplemented : ('a list *
                                                                    weight))
