let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec aux_node (node : ('a * weight)) (visited : 'a list) =
     (let (n, w) = node in
      if List.mem n visited
      then raise Fail
      else
        if n = b
        then ((n :: visited), w)
        else
          ((fun (v, t_w) -> (v, (t_w + w))))
            (aux_list (neighbours g n) (n :: visited)) : ('a list * weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) =
     (match nodes with
      | [] -> raise Fail
      | x::xs -> (try aux_node x visited with | Fail -> aux_list xs visited) : 
     ('a list * weight)) in
   aux_list (neighbours g a) [a] : ('a list * weight))
