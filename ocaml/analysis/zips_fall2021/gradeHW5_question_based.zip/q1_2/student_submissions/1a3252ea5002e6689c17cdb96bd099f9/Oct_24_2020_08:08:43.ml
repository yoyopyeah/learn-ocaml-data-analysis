let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec check_exist (a, b) visited =
     match visited with
     | [] -> false
     | x::xs -> if x = a then true else check_exist (a, b) xs in
   let rec aux_node (node : ('a * weight)) (visited : 'a list) (b : 'a) =
     (if check_exist node visited
      then raise Fail
      else
        (match node with
         | (a, c) ->
             if a = b
             then ((visited @ [a]), c)
             else aux_list (neighbours g a) (a :: visited) b) : ('a list *
                                                                  weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) (b : 'a) =
     (match nodes with
      | [] -> raise Fail
      | x::xs ->
          (try aux_node x visited b with | Fail -> aux_list xs visited b) : 
     ('a list * weight)) in
   aux_node (a, 0) [] b : ('a list * weight))
