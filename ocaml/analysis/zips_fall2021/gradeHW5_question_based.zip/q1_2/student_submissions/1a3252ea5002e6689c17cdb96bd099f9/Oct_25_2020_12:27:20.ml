let find_path (g : 'a graph) (a : 'a) (b : 'a) =
  (let rec find lists goal =
     match lists with
     | [] -> 0
     | a1::b1 -> let (x, y) = a1 in if x = goal then y else find b1 goal in
   let rec price (g : 'a graph) list acc =
     match list with
     | [] -> acc
     | a::[] -> acc
     | a::b::c ->
         price (g : 'a graph) (b :: c) (acc + (find (neighbours g a) b)) in
   let rec check_exist (a, b) visited =
     match visited with
     | [] -> false
     | x::xs -> if x = a then true else check_exist (a, b) xs in
   let rec aux_node (node : ('a * weight)) (visited : 'a list) money =
     (if check_exist node visited
      then raise Fail
      else
        (let (a, c) = node in
         if a = b
         then ((visited @ [a]), (money + c))
         else aux_list (neighbours g a) (visited @ [a]) c) : ('a list *
                                                               weight))
   and aux_list (nodes : ('a * weight) list) (visited : 'a list) money =
     (match nodes with
      | [] -> raise Fail
      | x::xs ->
          (try aux_node x visited money
           with | Fail -> aux_list xs visited money) : ('a list * weight)) in
   aux_node (a, 0) [] 0 : ('a list * weight))
