let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [A] [1 A];
  [];
  [C; C; C] [3 C]]
let compress (l : nucleobase list) =
  (let rec f x tail n =
     match tail with
     | [] -> [n x]
     | y::t -> if x = y then f y t (n + 1) else [n x] @ (f y t n) in
   match l with | [] -> [] | x::tail -> f x tail 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
