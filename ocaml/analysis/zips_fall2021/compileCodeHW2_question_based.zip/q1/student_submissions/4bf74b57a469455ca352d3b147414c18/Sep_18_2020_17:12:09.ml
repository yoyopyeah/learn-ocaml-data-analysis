let compress_tests =
  [[];
  [A] [1 A];
  [T] [1 T];
  [G] [1 G];
  [C] [1 C];
  [A; A] [2 A];
  [T; T; C; G; A] [2 T; 1 C; 1 G; 1 A];
  [G; T; T; C; C; G; G; A; A; A] [1 G; 2 T; 2 C; 2 G; 3 A]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
