let compress_tests =
  [[A] [1 A];
  [T] [1 T];
  [G] [1 G];
  [C] [1 C];
  [A; T; G; C] [1 A; 1 T; 1 G; 1 C];
  [A; A] [2 A];
  [T; T] [2 T];
  [G; G] [2 G];
  [C; C] [2 C];
  [T; T; C; G; A] [2 T; 1 C; 1 G; 1 A];
  [G; T; T; C; C; G; G; A; A; A] [1 G; 2 T; 2 C; 2 G; 3 A];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
