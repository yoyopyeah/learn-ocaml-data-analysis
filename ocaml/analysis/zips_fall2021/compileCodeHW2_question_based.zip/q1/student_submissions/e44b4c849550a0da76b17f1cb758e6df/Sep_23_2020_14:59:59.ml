let compress_tests =
  [[A; A; A; A; C; T; T; G] [4 A; 1 C; 2 T; 1 G];
  [A; A; T; T; A; A; A; G; G; C; C; C; A] [2 A; 2 T; 3 A; 2 G; 3 C; 1 A]]
let compress (l : nucleobase list) =
  (let rec helper (seq : nucleobase list) (acc : int) =
     (match seq with
      | [] -> []
      | h::t ->
          (match t with
           | h::u -> helper t (acc + 1)
           | _ -> (acc h) :: (helper t 1)) : (int * nucleobase) list) in
   match l with | [] -> [] | _ -> helper l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
