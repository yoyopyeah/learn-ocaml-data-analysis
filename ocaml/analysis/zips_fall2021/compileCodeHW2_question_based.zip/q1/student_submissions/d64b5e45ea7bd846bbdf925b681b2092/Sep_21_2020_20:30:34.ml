let compress_tests =
  [[A] [1 A]; [A; A; T; C] [2 A; 1 T; 1 C]; []; [A; A; A] [3 A]]
let compress (l : nucleobase list) =
  (let rec rev_com l acc =
     match l with
     | [] -> []
     | x::[] -> [acc x]
     | x::y::xs ->
         if x == y
         then let acc = acc + 1 in (acc x) :: (rev_com xs acc)
         else (let acc = 1 in (acc x) :: (rev_com (y :: xs) acc)) in
   rev_com l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
