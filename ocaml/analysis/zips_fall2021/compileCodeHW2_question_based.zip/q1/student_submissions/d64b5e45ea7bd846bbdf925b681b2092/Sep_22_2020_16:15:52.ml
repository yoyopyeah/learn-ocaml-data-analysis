let compress_tests =
  [[A] [1 A];
  [A; A; T; C] [2 A; 1 T; 1 C];
  [];
  [A; A; A] [3 A];
  [A; A; A; C; C] [3 A; 2 C];
  [A; A; A; C] [3 A; 1 C];
  [A; A; C; C; T; A] [2 A; 2 C; 1 T; 1 A]]
let compress (l : nucleobase list) =
  (let rec rev_com l a =
     match l with
     | [] -> []
     | x::[] -> [a x]
     | x::y::xs ->
         if x == y
         then let a = a + 1 in rev_com (y :: xs) a
         else (a x) :: (rev_com (y :: xs) 1) in
   rev_com l 1 : (int * nucleobase) list)
let decompress_tests =
  [[];
  [1 G] [G];
  [2 A] [A; A];
  [1 A; 1 T; 2 C] [A; T; C; C];
  [2 A; 1 C] [A; A; C]]
let rec decompress (l : (int * nucleobase) list) =
  (match l with | [] -> [] | x::xs -> [] : nucleobase list)
