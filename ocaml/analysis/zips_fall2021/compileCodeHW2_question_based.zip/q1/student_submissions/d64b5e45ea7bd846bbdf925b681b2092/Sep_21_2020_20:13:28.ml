let compress_tests = [[A] [1 A]; [A; A; T; C] [2 A; 1 T; 1 C]; []]
let compress (l : nucleobase list) =
  (let rec rev_com l =
     match l with | [] -> [] | x::[] -> [1 x] | x::y::xs -> [] in
   rev_com l : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
