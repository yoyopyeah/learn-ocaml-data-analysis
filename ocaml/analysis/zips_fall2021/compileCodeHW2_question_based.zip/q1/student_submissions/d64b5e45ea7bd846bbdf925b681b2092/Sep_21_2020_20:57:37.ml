let compress_tests =
  [[A] [1 A];
  [A; A; T; C] [2 A; 1 T; 1 C];
  [];
  [A; A; A] [3 A];
  [A; A; A; C; C] [3 A; 2 C]]
let compress (l : nucleobase list) =
  (let head = List.hd l in
   let rec rev_com l a =
     match l with
     | [] -> []
     | x::xs ->
         if head == x
         then let a = a + 1 in head = (List.hd xs)
         else (a head) :: (rev_com xs a) in
   rev_com l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
