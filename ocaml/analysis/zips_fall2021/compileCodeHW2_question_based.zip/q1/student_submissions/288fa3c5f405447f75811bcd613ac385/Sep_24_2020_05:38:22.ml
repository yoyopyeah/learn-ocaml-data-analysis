let compress_tests =
  [[A; A; A; A] [4 A];
  [A; A; A; A; G; G] [4 A; 2 G];
  [A; A; A; A; G; G; T; G; G; T; C; C] [4 A; 2 G; 1 T; 2 G; 1 T; 2 C];
  [A; A; A] [3 A];
  [A] [1 A];
  [A; A] [2 A];
  [A; T; G; C] [1 A; 1 T; 1 G; 1 C]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> [()]
   | i::[] -> [1 i]
   | h::t ->
       let rec count h t acc =
         match t with | [] -> acc | h'::t' -> if h = h' then unit in
       count h t 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
