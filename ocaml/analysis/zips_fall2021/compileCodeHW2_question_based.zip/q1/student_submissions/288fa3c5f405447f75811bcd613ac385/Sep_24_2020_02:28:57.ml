let compress_tests =
  [[A; A; A] (3 A);
  [A; A; A; A; G; G; A; T; T; T; C] [4 A; 2 G; 1 A; 3 T; 1 C]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
