let compress_tests =
  [[A; A; A; A] [4 A];
  [A; A; A; A; G; G] [4 A; 2 G];
  [A; A; A; A; G; G; T; G; G; T; C; C] [4 A; 2 G; 1 T; 2 G; 1 T; 2 C];
  [A; A; A] [3 A];
  [A] [1 A];
  [A; A] [2 A];
  [A; T; G; C] [1 A; 1 T; 1 G; 1 C]]
let compress (l : nucleobase list) =
  (let rec count l acc =
     match l with
     | [] -> []
     | i::[] -> [acc i]
     | head::(next::tail as t) ->
         if head == next
         then count t (acc + 1)
         else [acc + (1 head)] @ (count t 0) in
   count l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
