let compress_tests =
  [[A; A; A; A] [4 A];
  [A; A; A; A; G; G] [4 A; 2 G];
  [A; A; A; A] [4 A];
  [A; A; A; A] [4 A]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
