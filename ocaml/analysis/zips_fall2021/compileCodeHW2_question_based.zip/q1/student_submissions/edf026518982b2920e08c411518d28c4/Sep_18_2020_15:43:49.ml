let compress_tests = [[]; [A] [1 A]; [A; C] [1 A; 1 T]; [A; A] [2 A]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
