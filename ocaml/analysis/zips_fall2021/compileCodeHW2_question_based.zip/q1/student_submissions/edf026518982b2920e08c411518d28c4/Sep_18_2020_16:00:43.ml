let compress_tests =
  [[];
  [A] [1 A];
  [A; C] [1 A; 1 C];
  [A; A] [2 A];
  [A; A; A] [3 A];
  [A; A; A; T; T; G] [3 A; 2 T; 1 G]]
let compress (l : nucleobase list) =
  (let rec compress' remaining count compressed_list =
     match l with
     | [] -> []
     | x::[] -> compressed_list @ [1 x]
     | base1::base2::tail -> if base1 = base2 then compress' in
   compress' l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
