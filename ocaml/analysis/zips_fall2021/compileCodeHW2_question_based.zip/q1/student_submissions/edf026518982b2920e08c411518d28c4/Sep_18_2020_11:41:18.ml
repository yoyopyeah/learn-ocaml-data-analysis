let compress_tests = [[]; [A] [1 A]; [A; C] [1 A; 1 T]; [A; A] [2 A]]
let compress (l : nucleobase list) =
  (let rec helper l acc =
     match l with
     | [] -> list
     | base::[] -> list @ [1 base]
     | base1::base2::tail -> (helper base2) :: (tail (acc + 1)) in
   helper l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
