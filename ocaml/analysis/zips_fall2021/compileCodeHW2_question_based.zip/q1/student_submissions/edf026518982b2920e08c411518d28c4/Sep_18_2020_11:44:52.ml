let compress_tests = [[]; [A] [1 A]; [A; C] [1 A; 1 T]; [A; A] [2 A]]
let compress (l : nucleobase list) =
  (let rec helper l count compressed_list =
     match l with
     | [] -> compressed_list
     | base::[] -> compressed_list @ [1 base]
     | base1::base2::tail ->
         if base1 = base2
         then (helper base2) :: (tail (count + 1) compressed_list)
         else compressed_list @ (count compressed_list) in
   helper l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
