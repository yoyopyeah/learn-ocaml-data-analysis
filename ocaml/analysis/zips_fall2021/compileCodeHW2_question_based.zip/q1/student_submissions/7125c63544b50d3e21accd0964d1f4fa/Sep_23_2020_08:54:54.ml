let compress_tests =
  [[A; A; A; A] [4 A];
  [A; T; C; G] [1 A; 1 T; 1 C; 1 G];
  [T; T; T; T] [4 T];
  [A; A; T; T] [2 A; 2 T];
  [A; T; T; G] [1 A; 2 T; 1 G];
  [G] [1 G];
  [A; T; A; T] [1 A; 1 T; 1 A; 1 T];
  []]
let compress (l : nucleobase list) =
  (let rec comp_tr l newlist acc prev =
     match l with
     | [] -> newlist :: (acc prev)
     | h::t ->
         if prev = h
         then comp_tr t newlist (acc + 1) h
         else comp_tr t ((acc prev) :: newlist) 1 h in
   comp_tr l [] 0 A : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
