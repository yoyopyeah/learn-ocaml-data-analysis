let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [];
  [A] [1 A]]
let compress (l : nucleobase list) =
  (let rec helper acc count l =
     match l with
     | [] -> []
     | nucleobase::[] -> (count + (1 nucleobase)) :: acc
     | h::(y::t as list) ->
         if h = y
         then helper acc (count + 1) list
         else helper ((count + (1 h)) :: acc) 0 list
     | h::(y::_ as list) ->
         if h = y
         then helper acc (count + 1) list
         else helper ((count + (1 h)) :: acc) 0 list in
   helper [] 0 l : (int * nucleobase) list)
let decompress_tests =
  [[4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]
     [A; A; A; A; G; G; A; T; T; T; C; T; C];
  [1 A] [A];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (match l with | [] -> [] : nucleobase list)
