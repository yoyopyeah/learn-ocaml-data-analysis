let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [A; A; A; A; A] [5 A];
  [A; G; T; C] [1 A; 1 G; 1 T; 1 C];
  [A; A; A; G; G; T; G] [3 A; 2 G; 1 T; 1 G];
  [A] [1 A]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
