let compress_tests =
  [[A; A; A; A; A; A; A; A; A] [9 A];
  [A] [1 A];
  [A; C] [1 A; 1 C];
  [A; C; T; G] [1 A; 1 C; 1 T; 1 G]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [[9 A] [A; A; A; A; A; A; A; A; A]; [1 A] [A]; [1 A; 1 C] [A; C]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
