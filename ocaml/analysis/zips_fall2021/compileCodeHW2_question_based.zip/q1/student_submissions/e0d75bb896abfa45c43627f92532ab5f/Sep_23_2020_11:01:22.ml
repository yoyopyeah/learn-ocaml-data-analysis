let compress_tests = [[A G] [1 A; 1 G]]
let compress (l : nucleobase list) =
  (match l with | [] -> [] | h::t -> compress_helper t [] h 1 : (int *
                                                                  nucleobase)
                                                                  list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
