let compress_tests =
  [[A] [1 A];
  [A; A; A; A; A] [5 A];
  [A; A; G; A; A] [2 A; 1 G; 2 A];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  []]
let compress (l : nucleobase list) =
  (let head (h::t) = h in
   let tail (l : (int * nucleobase) list) =
     match l with | [] -> [] | h::t -> t in
   let rec choose_name (l1 : nucleobase list) (l2 : (int * nucleobase) list)
     =
     (match head l1 with
      | A -> [1 A]
      | T -> [1 A]
      | C -> [1 A]
      | G -> [1 A]
      | _ -> l2 : (int * nucleobase) list) in
   let new_name = [] in choose_name l new_name : (int * nucleobase) list)
let decompress_tests =
  [[1 A] [A];
  [5 A] [A; A; A; A; A];
  [2 A; 1 G; 2 A] [A; A; G; A; A];
  [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C] [A; A; A; A; G; G; A; T; T; T; C; T; C];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
