let compress_tests =
  [[A] [1 A];
  [A; A; A; A; A] [5 A];
  [A; A; G; A; A] [2 A; 1 G; 2 A];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  []]
let compress (l : nucleobase list) =
  (let head (l : nucleobase list) = match l with | [] -> [] | h::t -> [h] in
   let cut (l : nucleobase list) =
     match l with | x::[] -> [] | [] -> [] | x::y -> y in
   let rev (l : (int * nucleobase) list) =
     let rec rev_tr l acc =
       match l with | [] -> acc | h::t -> rev_tr t (h :: acc) in
     rev_tr l [] in
   let tail (l : (int * nucleobase) list) =
     match rev l with | [] -> [] | h::t -> [h] in
   let increase_tail (l : (int * nucleobase) list) =
     let the_tail = tail l in 0 in
   let rec compress_rec input_list output_list cur coun =
     match head input_list with
     | [] -> output_list
     | (A)::[] ->
         (match cur with
          | (A)::[] ->
              compress_rec (cut input_list) (output_list @ [7 A]) [A]
          | _ -> compress_rec (cut input_list) (output_list @ [1 A]) [A])
     | (T)::[] ->
         (match cur with
          | (T)::[] ->
              compress_rec (cut input_list) (output_list @ [7 T]) [T]
          | _ -> compress_rec (cut input_list) (output_list @ [1 T]) [T])
     | (C)::[] ->
         (match cur with
          | (C)::[] ->
              compress_rec (cut input_list) (output_list @ [7 C]) [C]
          | _ -> compress_rec (cut input_list) (output_list @ [1 C]) [C])
     | (G)::[] ->
         (match cur with
          | (G)::[] ->
              compress_rec (cut input_list) (output_list @ [7 G]) [G]
          | _ -> compress_rec (cut input_list) (output_list @ [1 G]) [G]) in
   compress_rec l [] [] 0 : (int * nucleobase) list)
let decompress_tests =
  [[1 A] [A];
  [5 A] [A; A; A; A; A];
  [2 A; 1 G; 2 A] [A; A; G; A; A];
  [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C] [A; A; A; A; G; G; A; T; T; T; C; T; C];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
