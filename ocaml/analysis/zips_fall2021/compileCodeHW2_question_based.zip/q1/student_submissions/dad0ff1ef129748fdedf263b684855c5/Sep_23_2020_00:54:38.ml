let compress_tests =
  [[A; A; A; A; A] [5 A];
  [A; A; G; A; A] [2 A; 1 G; 2 A];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  []]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [[(5 A) [A; A; A; A; A]];
  [2 A; 1 G; 2 A] [A; A; G; A; A];
  [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C] [A; A; A; A; G; G; A; T; T; T; C; T; C];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
