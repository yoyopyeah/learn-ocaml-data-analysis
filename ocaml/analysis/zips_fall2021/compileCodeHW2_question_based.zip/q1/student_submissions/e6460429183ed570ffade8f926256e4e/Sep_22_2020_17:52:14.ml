let compress_tests = [AAAAAAAA [8 A]; AACCTTGG [(2 A) (2 C) (2 T) (2 G)]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = [[8 A] AAAAAAAA; [(2 A) (2 C) (2 T) (2 G)] AACCTTGG]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
