let compress_tests =
  [[A; A; A; A; A; A; A; A] [8 A];
  [A; A; C; C; T; T; G; G] [2 A; 2 C; 2 T; 2 G]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [[8 A] [A; A; A; A; A; A; A; A];
  [2 A; 2 C; 2 T; 2 G] [A; A; C; C; T; T; G; G]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
