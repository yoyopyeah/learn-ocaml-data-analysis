let compress_tests =
  [[A; A; A; A; A; A; A; A] [8 A];
  [A; A; C; C; T; T; G; G] [2 A; 2 C; 2 T; 2 G]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | (T)::[] -> [int + (1 T)] @ l
   | (A)::[] -> [int + (1 A)] @ l
   | (C)::[] -> [int + (1 C)] @ l
   | (D)::[] -> [int + (1 D)] @ l
   | _::[] -> raise Error : (int * nucleobase) list)
let decompress_tests =
  [[8 A] [A; A; A; A; A; A; A; A];
  [2 A; 2 C; 2 T; 2 G] [A; A; C; C; T; T; G; G]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
