let compress_tests = [[A] [1 A]; [A; A] [2 A]; []]
let rec compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | x::[] -> [1 x]
   | x::y::[] -> if x = y then [2 x] else [1 x; 1 y]
   | x::y::z::tail ->
       let i = 1 in
       if x = y
       then
         (if y = z
          then [3 x] @ (compress tail)
          else [2 x] @ (compress (z :: tail)))
       else [1 x] @ (compress (y :: tail)) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
