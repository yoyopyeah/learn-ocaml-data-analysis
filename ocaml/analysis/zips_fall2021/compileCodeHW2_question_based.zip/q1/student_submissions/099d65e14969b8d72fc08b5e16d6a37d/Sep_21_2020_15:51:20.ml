let compress_tests = [[A] [1 A]; [A; A] [2 A]; []]
let rec compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | x::[] -> [1 x]
   | x::y::[] -> if x = y then [2 x] else [1 x; 1 y]
   | x::y::tail ->
       let z = 1 in
       let rec loop (x::y : tail) =
         if x = y
         then let z = z + 1 in loop (y :: tail)
         else [z x] @ (compress (y :: tail)) in
       loop (x :: y :: tail) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
