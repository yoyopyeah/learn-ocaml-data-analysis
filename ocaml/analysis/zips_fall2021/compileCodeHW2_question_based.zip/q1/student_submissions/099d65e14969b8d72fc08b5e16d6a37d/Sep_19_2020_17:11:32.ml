let compress_tests = [[A] [1 A]; [A; A] [2 A]; []]
let compress (l : nucleobase list) =
  (if l = []
   then []
   else (match l with | x::[] -> [1 x] | x::y::tail -> raise NotImplemented) : 
  (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
