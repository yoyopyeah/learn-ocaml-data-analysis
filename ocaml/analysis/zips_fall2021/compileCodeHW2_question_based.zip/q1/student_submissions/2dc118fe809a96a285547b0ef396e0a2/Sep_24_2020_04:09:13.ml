let compress_tests =
  [[];
  [A; A; A] [3 A];
  [T] [1 T];
  [A; A; C; G] [2 A; 1 C; 1 G];
  [A; A; C; G; G; T; T] [2 A; 1 C; 2 G; 2 T]]
let compress (l : nucleobase list) =
  (let rec aux counter accumulator =
     function
     | [] -> []
     | n::[] -> [counter + (1 n)] :: accumulator
     | a::(b::_ as t) ->
         if a = b
         then aux (counter + 1) accumulator t
         else aux 0 ((counter + (1 a)) :: accumulator) t in
   List.rev (aux 0 [] list) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
