let compress_tests =
  [[A; A; A] [3 A];
  [A; C; A; G] [2 A; 1 C; 1 G];
  [A; C; A; G; T; T; G] [2 A] [1 C] [2 G] [2 T]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
