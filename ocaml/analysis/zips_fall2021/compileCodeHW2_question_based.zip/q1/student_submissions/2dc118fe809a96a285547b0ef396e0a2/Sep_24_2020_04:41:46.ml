let compress_tests =
  [[];
  [A; A; A] [3 A];
  [T] [1 T];
  [A; A; C; G] [2 A; 1 C; 1 G];
  [A; A; C; G; G; T; T] [2 A; 1 C; 2 G; 2 T]]
let compress (l : nucleobase list) =
  (let rec extract count accum =
     match count accum with
     | n::[] -> [(count + 1) n] :: accum
     | a::(b::_ as t) ->
         if a = b
         then extract (count + 1) accum t
         else extract 0 ((count + (1 a)) :: accum) t in
   List.rev (extract 0 [] list) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
