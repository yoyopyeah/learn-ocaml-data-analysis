let compress_tests =
  [[];
  [A; A; A] [3 A];
  [T] [1 T];
  [A; A; C; G] [2 A; 1 C; 1 G];
  [A; A; C; G; G; T; T] [2 A; 1 C; 2 G; 2 T]]
let compress (l : nucleobase list) =
  (let rec comp_rec count accum =
     function
     | [] -> []
     | x::[] -> [(count + 1) x] :: accum
     | a::(b::_ as t) ->
         if a = b
         then comp_rec (count + 1) accum t
         else comp_rec 0 ((count + (1 a)) :: acc) t in
   List.rev (comp_rec 0 [] list) : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
