let compress_tests =
  [[]; [A] [1 A]; [A; A; G] [2 A; 1 G]; [A; A; G; G; G; A] [2 A; 3 G; 1 A]]
let compress (l : nucleobase list) =
  (let rec compressRec l n c =
     match l with
     | [] -> []
     | h::t ->
         (match h with
          | n -> [] @ ((compressRec t n c) + 1)
          | _ -> [c n] @ (compressRec t h 1)) in
   match l with | [] -> [] | h::t -> compressRec t h 1 : (int * nucleobase)
                                                           list)
let decompress_tests =
  [[]; [1 A] [A]; [2 A; 1 G] [A; A; G]; [2 A; 3 G; 1 A] [A; A; G; G; G; A]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
