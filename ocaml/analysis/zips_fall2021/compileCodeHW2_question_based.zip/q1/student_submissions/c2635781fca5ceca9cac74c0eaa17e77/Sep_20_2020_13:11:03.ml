let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compress_tr (l : nucleobase list) n acc clist =
     match l with
     | [] -> clist
     | h::t ->
         if n = []
         then compress_tr t h (acc + 1) clist
         else
           if h = n
           then compress_tr t n (acc + 1) clist
           else clist @ ([acc n] @ (compress_tr t h 0 clist)) in
   compress_tr l Empty 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
