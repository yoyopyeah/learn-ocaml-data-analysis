let compress_tests =
  [[A; A] [2 A]; [A] [1 A]; [A; A; G; G; T] [2 A; 2 G; 1 T]; []]
let compress (l : nucleobase list) =
  (match l with | i::tail -> [1 i] @ [1 i] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
