let compress_tests =
  [[A; A] [2 A]; [A] [1 A]; [A; A; G G; T] [2 A; 2 G; 1 T]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
