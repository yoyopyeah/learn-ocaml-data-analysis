let compress_tests = [[T] [1 T]; [A; T; T] [1 A; 2 T]; []]
let compress (l : nucleobase list) =
  (let rec aux_compress k new_list current_list =
     match current_list with
     | [] -> []
     | e::[] -> List.rev ((k + (1 e)) :: new_list)
     | h::(a::_ as rest) ->
         if h = a
         then aux_compress (k + 1) new_list rest
         else aux_compress 0 ((k + (1 h)) :: new_list) rest in
   aux_compress 0 [] l : (int * nucleobase) list)
let decompress_tests = [[]; [1 A; 2 T] [A; T; T]; [1 T] [T]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
