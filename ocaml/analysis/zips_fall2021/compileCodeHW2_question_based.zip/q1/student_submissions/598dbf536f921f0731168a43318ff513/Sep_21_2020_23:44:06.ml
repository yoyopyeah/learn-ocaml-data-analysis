let compress_tests =
  [[A; A; T; G; G; G; C] [2 A; 1 T; 3 G; 1 C];
  [A; G; T; C] [1 A; 1 G; 1 T; 1 C];
  [];
  [A] [1 A]]
let compress (l : nucleobase list) =
  (let rec add l last counter result =
     match l with
     | [] -> (counter last) :: result
     | head::tail ->
         if head == last
         then add tail last (counter + 1) result
         else
           (let result = (counter last) :: result in add tail head 1 result) in
   let rec rev l acc = match l with | [] -> acc | h::t -> rev t (h :: acc) in
   match l with | [] -> [] | head::tail -> rev (add l head 0 []) [] : 
  (int * nucleobase) list)
let decompress_tests =
  [[2 A; 1 T; 3 G; 1 C] [A; A; T; G; G; G; C];
  [1 A; 1 G; 1 T; 1 C] [A; G; T; C];
  [];
  [1 A] [A]]
let rec decompress (l : (int * nucleobase) list) =
  (let list = [] in
   match l with | [] -> list | head::tail -> head :: (list decompress tail) : 
  nucleobase list)
