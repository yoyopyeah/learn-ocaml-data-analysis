let compress_tests =
  [[A; A; T; G; G; G; C] [4 A; 1 T; 3 G; 1 C];
  [A; G; T; C] [1 A; 1 G; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let a t g c = 0 in
   let rec add l =
     match l with
     | [] -> 0
     | head::tail ->
         (match head with | A -> a + 1 | G -> g + 1 | T -> t + 1 | C -> c + 1) in
   add [] : (int * nucleobase) list)
