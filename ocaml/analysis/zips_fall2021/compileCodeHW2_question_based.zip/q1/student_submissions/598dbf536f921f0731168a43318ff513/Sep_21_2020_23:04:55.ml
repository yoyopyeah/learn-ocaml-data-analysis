let compress_tests =
  [[A; A; T; G; G; G; C] [2 A; 1 T; 3 G; 1 C];
  [A; G; T; C] [1 A; 1 G; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let rec add l last counter result =
     match l with
     | [] -> result
     | head::tail ->
         if head == last
         then (add tail last counter) + (1 result)
         else (counter last) :: (result add tail head 0 result) in
   match l with | [] -> [] | head::tail -> add l head 0 [] : (int *
                                                               nucleobase)
                                                               list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
