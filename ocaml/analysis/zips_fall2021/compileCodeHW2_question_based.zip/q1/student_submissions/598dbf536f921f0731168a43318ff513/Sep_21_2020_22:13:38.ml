let compress_tests =
  [[A; A; T; G; G; G; C] [4 A; 1 T; 3 G; 1 C];
  [A; G; T; C] [1 A; 1 G; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let a = 0 in
   let rec add l = match l with | [] -> [] | head::tail -> 0 in add [] : 
  (int * nucleobase) list)
