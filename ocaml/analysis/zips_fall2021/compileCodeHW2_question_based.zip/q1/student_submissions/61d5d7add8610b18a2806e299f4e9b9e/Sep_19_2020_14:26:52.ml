let compress_tests =
  [[];
  [C; C; C; C; C; C; C; C; C; C; C] [11 C];
  [[A; T; C; G] (1 A); 1 T; 1 C; 1 G];
  [A] [1 A];
  [[G; A; T; T] (1 G); 1 A; 2 T];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let rec compress_helper l l' n =
     match l with
     | [] -> l'
     | x::y::l ->
         if x = y
         then compress_helper l l' 2
         else compress_helper l ((n x) :: l') 1
     | x::l -> compress_helper l ((n x) :: l') 1 in
   compress_helper l [] 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
