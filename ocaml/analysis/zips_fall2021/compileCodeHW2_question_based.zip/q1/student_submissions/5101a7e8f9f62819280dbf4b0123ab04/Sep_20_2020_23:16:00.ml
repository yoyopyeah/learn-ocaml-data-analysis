let compress_tests = [[]; [A] [1 A]; [A; A] [2 A]; [A; A; C] [2 A; 1 C]]
let compress (l : nucleobase list) =
  (let rec rec_com l pre pair whole =
     match l with
     | [] -> whole
     | h::t ->
         if pre = h
         then rec_com t pre ([h] @ pair) whole
         else rec_com t h [h] (pair @ whole) in
   rec_com l None [] [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
