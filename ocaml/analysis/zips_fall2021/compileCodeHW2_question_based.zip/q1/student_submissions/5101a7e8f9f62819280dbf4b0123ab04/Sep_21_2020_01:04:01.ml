let compress_tests = [[]; [A] [1 A]; [A; A] [2 A]; [A; A; C] [2 A; 1 C]]
let compress (l : nucleobase list) =
  (let rec rec_com l n dna =
     match l with
     | [] -> dna
     | h::[] -> dna @ [n h]
     | h::hs::t ->
         if h = hs
         then rec_com (hs :: t) (n + 1) dna
         else rec_com (hs :: t) 1 (dna @ [n h]) in
   rec_com l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
