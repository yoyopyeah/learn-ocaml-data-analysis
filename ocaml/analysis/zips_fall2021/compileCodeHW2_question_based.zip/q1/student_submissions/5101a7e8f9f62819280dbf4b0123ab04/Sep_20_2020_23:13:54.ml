let compress_tests = [[]; [A] [1 A]; [A; A] [2 A]; [A; A; B] [2 A; 1 B]]
let compress (l : nucleobase list) =
  (let rec rec_com pre pair whole =
     match l with
     | [] -> whole
     | h::t ->
         if pre = h
         then rec_com pre ([h] @ pair) whole
         else rec_com h [h] (pair @ whole) in
   rec_com Empty [] [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
