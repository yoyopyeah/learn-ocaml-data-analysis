let compress_tests =
  [[1 A] A;
  [1 G] G;
  [2 A] AA;
  [1 A; 1 C] AC;
  [1 A; 2 G; 1 A] AGGA;
  [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C] AAAAGGATTTCTC]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
