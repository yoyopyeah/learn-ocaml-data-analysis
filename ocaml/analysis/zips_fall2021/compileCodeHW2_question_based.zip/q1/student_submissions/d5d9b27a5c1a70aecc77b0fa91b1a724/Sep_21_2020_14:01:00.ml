let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [A; A; A; A; A; A; A; A; A; A] [10 A];
  [A] [1 A];
  []]
let compress (l : nucleobase list) =
  (let rec compress' li c acc last =
     match l with
     | [] -> c
     | x::tail ->
         if x = last
         then compress' tail c (acc + 1) x
         else compress' tail (c @ [acc x]) 1 x in
   compress' l [] 1 A : (int * nucleobase) list)
let decompress_tests =
  [[4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]
     [A; A; A; A; G; G; A; T; T; T; C; T; C];
  [10 A] [A; A; A; A; A; A; A; A; A; A];
  [1 A] [A];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
