let new_account (p : passwd) =
  (let balance = ref 0 in
   let password = ref p in
   let attempts = ref 0 in
   let authentication3t pass input f =
     if (!password) = pass
     then f input
     else
       if (!attempts) < 3
       then (attempts := ((!attempts) + 1); raise too_many_attempts)
       else raise wrong_pass in
   let checkbalance payable =
     if payable > (!balance)
     then raise no_money
     else balance := ((!balance) - payable) in
   {
     update_passwd =
       (fun a ->
          fun b ->
            if (!password) = a
            then (attempts := 0; password := b)
            else raise wrong_pass);
     retrieve = (fun a -> fun b -> authentication3t a b checkbalance);
     deposit =
       (fun a ->
          fun b ->
            authentication3t a b (fun b -> balance := ((!balance) + b)));
     print_balance =
       (fun pass ->
          if (!password) = pass
          then !balance
          else
            if (!attempts) < 3
            then (attempts := ((!attempts) + 1); raise too_many_attempts)
            else raise wrong_pass)
   } : bank_account)
