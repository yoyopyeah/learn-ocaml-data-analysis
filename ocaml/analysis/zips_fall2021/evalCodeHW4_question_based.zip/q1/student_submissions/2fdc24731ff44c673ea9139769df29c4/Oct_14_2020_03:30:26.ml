let new_account (p : passwd) =
  (let pass_count = ref 0 in
   let pass = ref p in
   let balance = ref 0 in
   let is_equal a =
     if a = (!pass)
     then (pass_count := 0; true)
     else
       if (!pass_count) >= 3
       then raise too_many_attempts
       else (pass_count := ((!pass_count) + 1); raise wrong_pass) in
   {
     update_passwd =
       (fun try_pass ->
          fun new_pass -> if is_equal try_pass then pass := new_pass);
     retrieve =
       (fun try_pass ->
          fun withdraw ->
            if is_equal try_pass
            then
              (if (!balance) >= withdraw
               then balance := ((!balance) - withdraw)
               else raise no_money));
     deposit =
       (fun try_pass ->
          fun deposit ->
            if is_equal try_pass then balance := ((!balance) + deposit));
     print_balance =
       (fun try_pass ->
          if is_equal try_pass then !balance else raise wrong_pass)
   } : bank_account)
