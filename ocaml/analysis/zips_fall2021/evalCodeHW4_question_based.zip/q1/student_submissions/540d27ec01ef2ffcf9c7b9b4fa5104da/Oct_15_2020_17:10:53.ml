let new_account (p : passwd) =
  (let curPass = ref p in
   let balance = ref 0 in
   let numAttempts = ref 0 in
   let lock_acct = if (!numAttempts) > 3 then raise too_many_attempts in
   let checkPass (pass : passwd) =
     if pass = (!curPass)
     then (numAttempts := 0; true)
     else (numAttempts := ((!numAttempts) + 1); raise wrong_pass) in
   let update_passwd (oldPass : passwd) (newPass : passwd) =
     try let a = checkPass oldPass in if a = true then curPass := newPass
     with | wrong_pass -> lock_acct in
   let deposit (p : passwd) (add : int) =
     try
       let a = checkPass p in if a = true then balance := ((!balance) + add)
     with | wrong_pass -> lock_acct in
   let retrieve (p : passwd) (remove : int) =
     try
       let a = checkPass p in
       if a = true
       then
         (if remove <= (!balance)
          then balance := ((!balance) - remove)
          else raise no_money)
     with | wrong_pass -> lock_acct in
   let print_balance (p : passwd) =
     try let a = checkPass p in if a = true then !balance else 0
     with | wrong_pass -> (lock_acct; 0) in
   { update_passwd; retrieve; deposit; print_balance } : bank_account)
