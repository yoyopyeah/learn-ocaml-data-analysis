let new_account (p : passwd) =
  (let curPass = ref p in
   let balance = ref 0 in
   let numAttempts = ref 0 in
   let checkPass (pass : passwd) =
     if pass = (!curPass)
     then (numAttempts := 0; true)
     else
       (numAttempts := ((!numAttempts) + 1);
        if (!numAttempts) > 3 then raise too_many_attempts;
        raise wrong_pass) in
   {
     update_passwd =
       (fun (oldPass : passwd) ->
          fun (newPass : passwd) ->
            if oldPass = (!curPass)
            then curPass := newPass
            else raise wrong_pass);
     retrieve =
       (fun (p : passwd) ->
          fun (remove : int) ->
            if checkPass p
            then
              (if remove <= (!balance)
               then balance := ((!balance) - remove)
               else raise no_money));
     deposit =
       (fun (p : passwd) ->
          fun (add : int) ->
            if checkPass p then balance := ((!balance) + add));
     print_balance =
       (fun (p : passwd) -> if checkPass p then !balance else 0)
   } : bank_account)
