let new_account (p : passwd) =
  (let counter = ref 0 in
   let tick_counter () = counter := ((!counter) + 1) in
   let storedPassword = ref p in
   let balance = ref 0 in
   {
     update_passwd =
       (fun oldP ->
          fun newP ->
            if oldP != (!storedPassword)
            then (tick_counter (); raise wrong_pass)
            else (storedPassword := newP; counter := 0));
     deposit =
       (fun passwd ->
          fun amount ->
            if (!counter) > 2
            then raise too_many_attempts
            else
              if passwd != (!storedPassword)
              then (tick_counter (); raise wrong_pass)
              else (balance := ((!balance) + amount); counter := 0));
     retrieve =
       (fun passwd ->
          fun amount ->
            if (!counter) > 2
            then raise too_many_attempts
            else
              if passwd != (!storedPassword)
              then (tick_counter (); raise wrong_pass)
              else
                if (!balance) < amount
                then raise no_money
                else (balance := ((!balance) - amount); counter := 0));
     print_balance =
       (fun passwd ->
          if (!counter) > 2
          then raise too_many_attempts
          else
            if passwd != (!storedPassword)
            then (tick_counter (); raise wrong_pass)
            else counter := 0;
          !balance)
   } : bank_account)
