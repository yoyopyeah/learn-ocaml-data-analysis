let new_account (p : passwd) =
  (let pw = ref p in
   let balance = ref 0 in
   let wrong = ref 0 in
   {
     update_passwd =
       (fun old_pw ->
          fun new_pw ->
            if old_pw = (!pw)
            then (wrong := 0; pw := new_pw)
            else (wrong := ((!wrong) + 1); raise wrong_pass));
     retrieve =
       (fun password ->
          fun money ->
            if (!wrong) > 3
            then raise too_many_attempts
            else
              if password = (!pw)
              then
                (wrong := 0;
                 if money <= (!balance)
                 then balance := ((!balance) - money)
                 else raise no_money)
              else
                (wrong := ((!wrong) + 1);
                 if (!wrong) > 3
                 then raise too_many_attempts
                 else raise wrong_pass));
     deposit =
       (fun password ->
          fun money ->
            if (!wrong) > 3
            then raise too_many_attempts
            else
              if password = (!pw)
              then (wrong := 0; balance := ((!balance) + money))
              else
                (wrong := ((!wrong) + 1);
                 if (!wrong) > 3
                 then raise too_many_attempts
                 else raise wrong_pass));
     print_balance =
       (fun password ->
          if (!wrong) > 3
          then raise too_many_attempts
          else
            if password = (!pw)
            then (wrong := 0; !balance)
            else
              (wrong := ((!wrong) + 1);
               if (!wrong) > 3
               then raise too_many_attempts
               else raise wrong_pass))
   } : bank_account)
