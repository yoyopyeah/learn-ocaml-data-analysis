let new_account (p : passwd) =
  (let password = ref p in
   {
     update_passwd =
       (((((fun enter ->
              if enter == p
              then fun newPasswd -> password := newPasswd
              else raise wrong_pass) retrieve)
            = ())
           = ())
          = ())
   } raise NotImplemented : bank_account)
