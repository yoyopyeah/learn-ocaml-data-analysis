let new_account (p : passwd) =
  (let password = ref p in
   let count = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun input ->
          if (!password) == input
          then fun newPW -> password := newPW
          else (count := ((!count) + 1); raise wrong_pass));
     retrieve =
       (fun input ->
          if (!count) < 3
          then
            (if (!password) == input
             then
               fun amount ->
                 (if (!balance) >= amount
                  then balance := ((!balance) - amount)
                  else raise no_money)
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts);
     deposit =
       (fun input ->
          if (!count) < 3
          then
            (if (!password) == input
             then fun amount -> balance := ((!balance) + amount)
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts);
     print_balance =
       (fun input ->
          if (!count) < 3
          then
            (if (!password) == input
             then !balance
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts)
   } : bank_account)
