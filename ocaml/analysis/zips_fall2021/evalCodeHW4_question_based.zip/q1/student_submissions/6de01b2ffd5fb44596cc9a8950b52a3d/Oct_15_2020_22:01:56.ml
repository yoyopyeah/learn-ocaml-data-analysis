let new_account (p : passwd) =
  (let password = ref p in
   let count = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun (input : passwd) ->
          if (!password) = input
          then fun newPW -> (password := newPW; count := 0)
          else (count := ((!count) + 1); raise wrong_pass));
     retrieve =
       (fun (input : passwd) ->
          if (!count) < 3
          then
            (if (!password) = input
             then
               (count := 0;
                (fun amount ->
                   if (!balance) >= amount
                   then balance := ((!balance) - amount)
                   else raise no_money))
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts);
     deposit =
       (fun (input : passwd) ->
          if (!count) < 3
          then
            (if (!password) = input
             then
               (count := 0; (fun amount -> balance := ((!balance) + amount)))
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts);
     print_balance =
       (fun (input : passwd) ->
          if (!count) < 3
          then
            (if (!password) = input
             then (count := 0; !balance)
             else (count := ((!count) + 1); raise wrong_pass))
          else raise too_many_attempts)
   } : bank_account)
