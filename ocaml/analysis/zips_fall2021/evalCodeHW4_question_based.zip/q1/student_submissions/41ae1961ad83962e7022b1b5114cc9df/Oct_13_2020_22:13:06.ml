let new_account (p : passwd) =
  (let pass = ref p in
   let balance = ref 0 in
   let counter = ref 0 in
   {
     update_passwd =
       (fun oldp ->
          fun newp ->
            if oldp = (!pass)
            then (pass := newp; counter := 0)
            else (counter := ((!counter) + 1); raise wrong_pass));
     retrieve =
       (fun p ->
          fun amount ->
            if (!counter) >= 3
            then raise too_many_attempts
            else
              if p = (!pass)
              then
                (if amount <= (!balance)
                 then (balance := ((!balance) - amount); counter := 0)
                 else raise no_money)
              else (counter := ((!counter) + 1); raise wrong_pass));
     deposit =
       (fun p ->
          fun amount ->
            if (!counter) >= 3
            then raise too_many_attempts
            else
              if p = (!pass)
              then (balance := ((!balance) + amount); counter := 0)
              else (counter := ((!counter) + 1); raise wrong_pass));
     print_balance =
       (fun p ->
          if (!counter) >= 3
          then raise too_many_attempts
          else
            if p = (!pass)
            then (counter := 0; !balance)
            else (counter := ((!counter) + 1); raise wrong_pass))
   } : bank_account)
