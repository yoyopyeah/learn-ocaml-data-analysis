let new_account (p : passwd) =
  (let pass = ref p in
   let amount = ref 0 in
   let numTries = ref 0 in
   {
     update_passwd = (fun pa -> fun np -> pass := np);
     retrieve =
       (fun pa ->
          fun withdrawed ->
            if pa = (!pass)
            then
              (if ((!amount) - withdrawed) >= 0
               then amount := ((!amount) - withdrawed)
               else raise no_money)
            else numTries := ((!numTries) + 1));
     deposit =
       (fun pa ->
          fun depo ->
            if pa = (!pass)
            then amount := (depo + (!amount))
            else numTries := ((!numTries) + 1));
     print_balance =
       (fun pa ->
          if pa = (!pass) then !amount else numTries := ((!numTries) + 1))
   } : bank_account)
