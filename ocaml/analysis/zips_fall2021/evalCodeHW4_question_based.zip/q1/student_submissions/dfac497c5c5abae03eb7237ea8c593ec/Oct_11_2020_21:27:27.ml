let new_account (p : passwd) =
  (let pass = ref p in
   let amount = ref 0 in
   let numTries = ref 1 in
   {
     update_passwd =
       (fun pa ->
          fun np ->
            if pa = (!pass)
            then (pass := np; numTries := 0)
            else raise wrong_pass);
     retrieve =
       (fun pa ->
          fun withdrawed ->
            if (!numTries) > 3
            then raise too_many_attempts
            else
              if pa = (!pass)
              then
                (if ((!amount) - withdrawed) >= 0
                 then amount := ((!amount) - withdrawed)
                 else raise no_money)
              else (numTries := ((!numTries) + 1); raise wrong_pass));
     deposit =
       (fun pa ->
          fun depo ->
            if (!numTries) > 3
            then raise too_many_attempts
            else
              if pa = (!pass)
              then amount := (depo + (!amount))
              else (numTries := ((!numTries) + 1); raise wrong_pass));
     print_balance =
       (fun pa ->
          if (!numTries) > 3
          then raise too_many_attempts
          else
            if pa = (!pass)
            then !amount
            else (numTries := ((!numTries) + 1); raise wrong_pass))
   } : bank_account)
