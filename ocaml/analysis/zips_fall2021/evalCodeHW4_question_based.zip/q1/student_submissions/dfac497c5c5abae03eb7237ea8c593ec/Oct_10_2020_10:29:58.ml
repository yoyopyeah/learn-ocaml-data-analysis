let new_account (p : passwd) =
  (let pass = ref p in
   let amount = ref 0 in
   let numTries = ref 0 in
   {
     update_passwd = (fun pa -> fun np -> pass := np; numTries := 0);
     retrieve =
       (fun pa ->
          fun withdrawed ->
            if (!numTries) > 3
            then raise too_many_attempts
            else
              if pa = (!pass)
              then
                (if ((!amount) - withdrawed) >= 0
                 then amount := ((!amount) - withdrawed)
                 else raise no_money)
              else raise wrong_pass);
     deposit =
       (fun pa ->
          fun depo ->
            if (!numTries) > 3
            then raise too_many_attempts
            else
              if pa = (!pass)
              then amount := (depo + (!amount))
              else raise wrong_pass);
     print_balance =
       (fun pa ->
          if (!numTries) > 3
          then raise too_many_attempts
          else
            if pa = (!pass)
            then !amount
            else (try numTries := ((!numTries) + 1) with | wrong_pass -> 0))
   } : bank_account)
