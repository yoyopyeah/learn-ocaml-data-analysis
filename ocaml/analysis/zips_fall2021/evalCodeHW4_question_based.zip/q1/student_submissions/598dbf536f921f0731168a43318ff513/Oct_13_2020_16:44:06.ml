let new_account (p : passwd) =
  (let password = ref p in
   let pass_needs_change = ref false in
   let c_wrong_p = ref 0 in
   let balance = ref 0 in
   let verify p =
     if p = (!password)
     then (pass_needs_change := false; c_wrong_p := 0; true)
     else
       if (!c_wrong_p) > 3
       then (pass_needs_change := true; raise too_many_attempts)
       else (c_wrong_p := ((!c_wrong_p) + 1); raise wrong_pass) in
   {
     update_passwd =
       (fun (ps : passwd) ->
          fun (np : passwd) ->
            (if p = (!password)
             then
               (pass_needs_change := false; c_wrong_p := 0; password := np)
             else (c_wrong_p := ((!c_wrong_p) + 1); raise wrong_pass) : 
            unit));
     retrieve =
       (fun ps ->
          fun i ->
            (if verify ps
             then
               (if i < (!balance)
                then raise no_money
                else balance := ((!balance) - i)) : unit));
     deposit =
       (fun (ps : passwd) ->
          fun (i : int) ->
            (if verify ps then balance := ((!balance) + i) : unit));
     print_balance = (fun ps -> if verify ps then !balance else 0)
   } : bank_account)
