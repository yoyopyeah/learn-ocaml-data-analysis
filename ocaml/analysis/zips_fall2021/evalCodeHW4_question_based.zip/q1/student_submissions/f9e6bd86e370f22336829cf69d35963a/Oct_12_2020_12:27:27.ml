let new_account (p : passwd) = (raise NotImplemented : bank_account)
