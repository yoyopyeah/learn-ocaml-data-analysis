let new_account (p : passwd) =
  (let password = ref p in
   let balance = ref 0 in
   let attempts = ref 0 in
   let update_passwd oldPass newPass =
     if oldPass = (!password)
     then (attempts := 0; password := newPass)
     else (attempts := ((!attempts) + 1); raise wrong_pass) in
   let retrieve pass amount =
     if (!attempts) > 2
     then raise too_many_attempts
     else
       if (!password) = pass
       then
         (attempts := 0;
          if amount > (!balance)
          then raise no_money
          else balance := ((!balance) - amount))
       else (attempts := ((!attempts) + 1); raise wrong_pass) in
   let deposit pass amount =
     if (!attempts) > 2
     then raise too_many_attempts
     else
       if (!password) = pass
       then (attempts := 0; balance := ((!balance) + amount))
       else (attempts := ((!attempts) + 1); raise wrong_pass) in
   let print_balance pass =
     (if (!attempts) > 2
      then raise too_many_attempts
      else
        if (!password) = pass
        then (attempts := 0; !balance)
        else (attempts := ((!attempts) + 1); raise wrong_pass) : int) in
   { update_passwd; retrieve; deposit; print_balance } : bank_account)
