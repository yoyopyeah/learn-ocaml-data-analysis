let new_account (p : passwd) =
  (let password = ref p in
   let balance = ref 0 in
   let attempts = ref 0 in
   let update_passwd oldPass newPass =
     if oldPass = (!password) then password := newPass else raise wrong_pass in
   let retrieve pass amount =
     if (!password) = pass
     then
       (if amount > (!balance)
        then raise no_money
        else balance := ((!balance) - amount))
     else raise wrong_pass in
   let deposit pass amount =
     if (!password) = pass
     then balance := ((!balance) + amount)
     else raise wrong_pass in
   let print_balance pass =
     if (!password) = pass then !balance else raise wrong_pass in
   { update_passwd; retrieve; deposit; print_balance } : bank_account)
