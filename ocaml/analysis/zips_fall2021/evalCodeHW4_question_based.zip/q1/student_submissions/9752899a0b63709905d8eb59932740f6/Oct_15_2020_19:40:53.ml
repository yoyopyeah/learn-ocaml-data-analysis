let new_account (p : passwd) =
  (let password = ref p in
   let password_attempts = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun current_p ->
          fun new_p ->
            if current_p = (!password)
            then (password_attempts := 0; password := new_p)
            else
              (password_attempts := ((!password_attempts) + 1);
               raise wrong_pass));
     retrieve =
       (fun current_p ->
          fun amt ->
            if (!password_attempts) >= 3
            then raise too_many_attempts
            else
              if current_p = (!password)
              then (password_attempts := 0; balance := ((!balance) - amt))
              else
                (password_attempts := ((!password_attempts) + 1);
                 raise wrong_pass));
     deposit =
       (fun current_p ->
          fun amt ->
            if (!password_attempts) >= 3
            then raise too_many_attempts
            else
              if current_p = (!password)
              then (password_attempts := 0; balance := ((!balance) + amt))
              else
                (password_attempts := ((!password_attempts) + 1);
                 raise wrong_pass));
     print_balance =
       (fun current_p ->
          if (!password_attempts) >= 3
          then raise too_many_attempts
          else
            if current_p = (!password)
            then (password_attempts := 0; !balance)
            else
              (password_attempts := ((!password_attempts) + 1);
               raise wrong_pass))
   } : bank_account)
