let new_account (p : passwd) =
  (let password = ref p in
   let password_attempts = ref 0 in
   let balance = ref 0 in
   {
     update_passwd = (fun current_p -> fun new_p -> password := new_p);
     retrieve = (fun current_p -> fun amt -> balance := ((!balance) - amt));
     deposit = (fun current_p -> fun amt -> balance := ((!balance) + amt));
     print_balance = (fun current_p -> !balance)
   } : bank_account)
