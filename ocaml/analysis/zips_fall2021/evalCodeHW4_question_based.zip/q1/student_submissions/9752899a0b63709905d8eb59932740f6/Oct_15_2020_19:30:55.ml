let new_account (p : passwd) =
  (let password = ref p in
   let password_attempts = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun current_p ->
          fun new_p ->
            if current_p != (!password)
            then
              (password_attempts := ((!password_attempts) + 1);
               raise wrong_pass)
            else password := new_p);
     retrieve =
       (fun current_p ->
          fun amt ->
            if current_p != (!password)
            then
              (password_attempts := ((!password_attempts) + 1);
               raise wrong_pass)
            else
              if amt > (!balance)
              then raise no_money
              else balance := ((!balance) - amt));
     deposit =
       (fun current_p ->
          fun amt ->
            if current_p != (!password)
            then
              (password_attempts := ((!password_attempts) + 1);
               raise wrong_pass)
            else balance := ((!balance) + amt));
     print_balance =
       (fun current_p ->
          if current_p != (!password) then !password else !balance)
   } : bank_account)
