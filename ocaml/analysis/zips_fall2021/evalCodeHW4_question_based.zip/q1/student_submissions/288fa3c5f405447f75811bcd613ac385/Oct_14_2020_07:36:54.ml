let new_account (p : passwd) =
  (let password = ref p in
   let account = ref 0 in
   let counter = ref 0 in
   {
     update_passwd =
       (fun oldpwd ->
          fun newpwd ->
            if oldpwd = (!password)
            then (password := newpwd; counter := 0)
            else raise wrong_pass);
     retrieve =
       (fun passwd ->
          fun amount ->
            if (!counter) > 2
            then raise too_many_attempts
            else
              if passwd = (!password)
              then
                (if amount > (!account)
                 then raise no_money
                 else account := ((!account) - amount))
              else (counter := ((!counter) + 1); raise wrong_pass));
     deposit =
       (fun passwd ->
          fun amount ->
            if (!counter) > 2
            then raise too_many_attempts
            else
              if passwd = (!password)
              then account := ((!account) + amount)
              else (counter := ((!counter) + 1); raise wrong_pass));
     print_balance =
       (fun passwd ->
          if (!counter) > 2
          then raise too_many_attempts
          else
            if passwd <> (!password)
            then (counter := ((!counter) + 1); raise wrong_pass)
            else ();
          !account)
   } : bank_account)
