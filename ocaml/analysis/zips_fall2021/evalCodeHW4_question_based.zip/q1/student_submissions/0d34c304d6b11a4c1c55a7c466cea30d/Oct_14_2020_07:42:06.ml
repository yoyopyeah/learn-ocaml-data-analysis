let new_account (p : passwd) =
  (let pass = ref p in
   let bal = ref 0 in
   let counter = ref 0 in
   {
     update_passwd =
       (fun old ->
          fun now ->
            if old == (!pass)
            then (pass := now; counter := 0)
            else (counter := ((!counter) + 1); raise wrong_pass));
     retrieve =
       (fun a ->
          fun b ->
            if (!counter) < 3
            then
              (if a == (!pass)
               then
                 (if (!bal) > b
                  then (bal := ((!bal) - b); counter := 0)
                  else raise no_money)
               else (counter := ((!counter) + 1); raise wrong_pass))
            else raise too_many_attempts);
     deposit =
       (fun a ->
          fun b ->
            if (!counter) < 3
            then
              (if a == (!pass)
               then (bal := ((!bal) + b); counter := 0)
               else (counter := ((!counter) + 1); raise wrong_pass))
            else raise too_many_attempts);
     print_balance =
       (if (!counter) < 3
        then
          fun a ->
            (if a == (!pass)
             then (counter := 0; !bal)
             else (counter := ((!counter) + 1); raise wrong_pass))
        else raise too_many_attempts)
   } : bank_account)
