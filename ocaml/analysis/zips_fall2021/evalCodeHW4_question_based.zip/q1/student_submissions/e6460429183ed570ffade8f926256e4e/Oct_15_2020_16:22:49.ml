let new_account (p : passwd) =
  (let balance = ref 0 in
   let pw = ref p in
   let attempt_acc = ref 0 in
   {
     update_passwd =
       (fun (old_pass : string) ->
          fun (new_pass : string) ->
            if (!pw) = old_pass
            then (pw := new_pass; attempt_acc := 0)
            else (attempt_acc := ((!attempt_acc) + 1); raise wrong_pass));
     deposit =
       (fun (pass : string) ->
          fun (depo : int) ->
            if (!attempt_acc) >= 3
            then raise too_many_attempts
            else
              if (!pw) = pass
              then (balance := ((!balance) + depo); attempt_acc := 0)
              else (attempt_acc := ((!attempt_acc) + 1); raise wrong_pass));
     retrieve =
       (fun (pass : string) ->
          fun (withdrawal : int) ->
            if (!attempt_acc) >= 3
            then raise too_many_attempts
            else
              if (!pw) = pass
              then
                (if withdrawal > (!balance)
                 then raise no_money
                 else
                   (balance := ((!balance) - withdrawal); attempt_acc := 0))
              else (attempt_acc := ((!attempt_acc) + 1); raise wrong_pass));
     print_balance =
       (fun (pass : string) ->
          if (!attempt_acc) >= 3
          then raise too_many_attempts
          else
            if (!pw) = pass
            then (attempt_acc := 0; !balance)
            else (attempt_acc := ((!attempt_acc) + 1); raise wrong_pass))
   } : bank_account)
