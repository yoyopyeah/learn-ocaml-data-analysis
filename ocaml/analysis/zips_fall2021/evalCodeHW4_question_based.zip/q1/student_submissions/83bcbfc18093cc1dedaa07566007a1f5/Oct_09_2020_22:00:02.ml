let new_account (p : passwd) =
  (let bal = ref 0 in
   let pass = ref p in
   let wrong = ref 0 in
   let account = ref (bal pass wrong) in
   {
     update_passwd =
       (fun pwd ->
          fun newp ->
            if pwd = (!pass)
            then (pass := newp; wrong := 0)
            else (wrong := ((!wrong) + 1); raise wrong_pass));
     retrieve =
       (fun pwd ->
          fun amount ->
            if amount < (!bal)
            then
              (if pwd = (!pass)
               then (bal := ((!bal) - amount); wrong := 0)
               else (wrong := ((!wrong) + 1); raise wrong_pass)));
     deposit =
       (fun pwd ->
          fun amount ->
            if pwd = (!pass)
            then (bal := ((!bal) + amount); wrong := 0)
            else (wrong := ((!wrong) + 1); raise wrong_pass));
     print_balance =
       (fun pwd ->
          if pwd = (!pass)
          then (wrong := 0; !bal)
          else (wrong := ((!wrong) + 1); raise wrong_pass))
   } : bank_account)
