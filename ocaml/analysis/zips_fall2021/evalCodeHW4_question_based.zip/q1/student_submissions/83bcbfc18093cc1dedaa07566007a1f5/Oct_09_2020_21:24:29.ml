let new_account (p : passwd) =
  (let bal = ref 0 in
   let pass = ref p in
   let account = ref (bal pass) in
   {
     update_passwd =
       (fun pwd -> fun newp -> if pwd = (!pass) then pass := newp else ());
     retrieve =
       (fun pwd ->
          fun amount ->
            if pwd = (!pass)
            then (if amount >= (!bal) then bal := ((!bal) - amount) else ())
            else ());
     deposit =
       (fun pwd ->
          fun amount ->
            if pwd = (!pass) then bal := ((!bal) + amount) else ());
     print_balance = (fun pwd -> if pwd = (!pass) then 0 else 1)
   } : bank_account)
