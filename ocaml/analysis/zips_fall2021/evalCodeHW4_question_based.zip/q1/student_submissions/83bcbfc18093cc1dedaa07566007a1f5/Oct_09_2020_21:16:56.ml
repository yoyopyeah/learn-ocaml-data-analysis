let new_account (p : passwd) =
  (let bal = ref 0 in
   let pass = ref p in
   let account = ref (bal pass) in
   {
     update_passwd = (fun pwd -> fun newp -> match pwd with | pass -> ());
     retrieve = (fun pwd -> fun int -> ());
     deposit = (fun pwd -> fun int -> ());
     print_balance = (fun pwd -> match pwd with | pass -> 0 | _ -> 1)
   } : bank_account)
