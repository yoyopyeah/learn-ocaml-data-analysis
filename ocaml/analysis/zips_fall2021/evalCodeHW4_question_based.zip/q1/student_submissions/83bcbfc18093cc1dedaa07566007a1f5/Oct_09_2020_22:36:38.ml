let new_account (p : passwd) =
  (let bal = ref 0 in
   let pass = ref p in
   let wrong = ref 0 in
   let toowrong = ref false in
   let account = ref (bal pass wrong toowrong) in
   {
     update_passwd =
       (fun pwd ->
          fun newp ->
            if pwd = (!pass)
            then (pass := newp; wrong := 0; toowrong := false)
            else
              (wrong := ((!wrong) + 1);
               if (!wrong) > 3 then toowrong := true;
               raise wrong_pass));
     retrieve =
       (fun pwd ->
          fun amount ->
            if (!toowrong) = true
            then raise too_many_attempts
            else
              if (pwd = (!pass)) && (amount <= (!bal))
              then (bal := ((!bal) - amount); wrong := 0)
              else
                if pwd != (!pass)
                then
                  (wrong := ((!wrong) + 1);
                   if (!wrong) <= 3
                   then raise wrong_pass
                   else (toowrong := true; raise too_many_attempts))
                else raise no_money);
     deposit =
       (fun pwd ->
          fun amount ->
            if !toowrong
            then raise too_many_attempts
            else
              if pwd = (!pass)
              then (bal := ((!bal) + amount); wrong := 0)
              else
                (wrong := ((!wrong) + 1);
                 if (!wrong) > 3
                 then (toowrong := true; raise too_many_attempts)
                 else raise wrong_pass));
     print_balance =
       (fun pwd ->
          if !toowrong
          then raise too_many_attempts
          else
            if pwd = (!pass)
            then (wrong := 0; !bal)
            else
              (wrong := ((!wrong) + 1);
               if (!wrong) > 3
               then (toowrong := true; raise too_many_attempts)
               else raise wrong_pass))
   } : bank_account)
