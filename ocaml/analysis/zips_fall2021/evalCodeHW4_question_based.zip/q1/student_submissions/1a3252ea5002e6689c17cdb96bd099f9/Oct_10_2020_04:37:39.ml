let new_account (p : passwd) =
  (let current_pass = ref p in
   let balance = ref 0 in
   let wrong = ref 0 in
   {
     update_passwd =
       (fun current ->
          fun new_pass ->
            if current = (!current_pass)
            then (wrong := 0; current_pass := new_pass)
            else raise wrong_pass);
     retrieve =
       (fun pass ->
          fun money ->
            if (!wrong) >= 3
            then raise too_many_attempts
            else
              if pass = (!current_pass)
              then
                (if (!balance) >= money
                 then (wrong := 0; balance := ((!balance) - money))
                 else (wrong := 0; raise no_money))
              else (wrong := ((!wrong) + 1); raise wrong_pass));
     deposit =
       (fun pass ->
          fun money ->
            if (!wrong) >= 3
            then raise too_many_attempts
            else
              if pass = (!current_pass)
              then (wrong := 0; balance := ((!balance) + money))
              else (wrong := ((!wrong) + 1); raise wrong_pass));
     print_balance =
       (fun pass ->
          if (!wrong) >= 3
          then raise too_many_attempts
          else
            if pass = (!current_pass)
            then (wrong := 0; !balance)
            else (wrong := ((!wrong) + 1); raise wrong_pass))
   } : bank_account)
