let new_account (p : passwd) =
  (let balance = ref 0
   and pwd = ref p
   and wrong = ref 0 in
   {
     update_passwd =
       (fun oldpwd ->
          fun newpwd ->
            if (!pwd) = oldpwd
            then (wrong := 0; pwd := newpwd)
            else (wrong := ((!wrong) + 1); raise wrong_pass));
     retrieve =
       (fun passwd ->
          fun money ->
            if (!wrong) >= 3
            then raise too_many_attempts
            else
              if passwd = (!pwd)
              then
                (if money > (!balance)
                 then (wrong := 0; raise no_money)
                 else (wrong := 0; balance := ((!balance) - money)))
              else (wrong := ((!wrong) + 1); raise wrong_pass));
     deposit =
       (fun passwd ->
          fun deposit ->
            if (!wrong) >= 3
            then (wrong := ((!wrong) + 1); raise too_many_attempts)
            else
              if passwd = (!pwd)
              then (wrong := 0; balance := ((!balance) + deposit))
              else (wrong := ((!wrong) + 1); raise wrong_pass));
     print_balance =
       (fun passwd ->
          if (!wrong) >= 3
          then (wrong := ((!wrong) + 1); raise too_many_attempts)
          else
            if passwd = (!pwd)
            then (wrong := 0; !balance)
            else (wrong := ((!wrong) + 1); raise wrong_pass))
   } : bank_account)
