let new_account (p : passwd) =
  (let balance = ref 0 in
   let curr_pass = ref p in
   let attempts = ref 0 in
   let add_attempts att = att := ((!att) + 1) in
   let reset att = att := 0 in
   {
     update_passwd =
       (fun old_pass ->
          fun new_pass ->
            if old_pass = (!curr_pass)
            then (reset attempts; curr_pass := new_pass)
            else (add_attempts attempts; raise wrong_pass));
     retrieve =
       (fun pass ->
          fun amount ->
            if (pass = (!curr_pass)) && ((!attempts) < 3)
            then
              (if (!balance) < amount
               then raise no_money
               else (reset attempts; balance := ((!balance) - amount)))
            else
              (add_attempts attempts;
               if (!attempts) < 4
               then raise wrong_pass
               else raise too_many_attempts));
     deposit =
       (fun pass ->
          fun amount ->
            if (pass = (!curr_pass)) && ((!attempts) < 3)
            then (reset attempts; balance := ((!balance) + amount))
            else
              (add_attempts attempts;
               if (!attempts) < 4
               then raise wrong_pass
               else raise too_many_attempts));
     print_balance =
       (fun pass ->
          if (pass = (!curr_pass)) && ((!attempts) < 3)
          then (reset attempts; !balance)
          else
            (add_attempts attempts;
             if (!attempts) < 4
             then raise wrong_pass
             else raise too_many_attempts))
   } : bank_account)
