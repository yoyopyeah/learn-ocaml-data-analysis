let new_account (p : passwd) =
  (let balance = ref 0 in
   let curr_pass = ref p in
   let attempts = ref 0 in
   let add_attempts att = att := ((!att) + 1) in
   {
     update_passwd =
       (fun old_pass ->
          fun new_pass ->
            if (old_pass = (!curr_pass)) && ((!attempts) < 4)
            then curr_pass := new_pass
            else
              (add_attempts attempts;
               if (!attempts) < 4
               then raise wrong_pass
               else raise too_many_attempts));
     retrieve =
       (fun pass ->
          fun amount ->
            if pass = (!curr_pass) then balance := ((!balance) - amount));
     deposit =
       (fun pass ->
          fun amount ->
            if pass = (!curr_pass) then balance := ((!balance) + amount));
     print_balance = (fun pass -> 2)
   } : bank_account)
