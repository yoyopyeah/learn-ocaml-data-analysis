let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compressing l acc =
     match l with | [] -> acc | h::t -> compressing t (h :: acc) in
   compressing [] [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
