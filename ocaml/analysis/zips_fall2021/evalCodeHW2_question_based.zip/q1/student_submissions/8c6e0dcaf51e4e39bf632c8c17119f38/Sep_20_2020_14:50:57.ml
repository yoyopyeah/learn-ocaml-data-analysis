let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | head::tail ->
       let rec compr nlist lastn num_consec =
         match nlist with
         | [] -> [num_consec lastn]
         | h2::t2 ->
             (match lastn with
              | A -> (num_consec lastn) :: (compr t2 A 1)
              | C -> (num_consec lastn) :: (compr t2 C 1)
              | G -> (num_consec lastn) :: (compr t2 G 1)
              | T -> (num_consec lastn) :: (compr t2 T 1)
              | lastn -> compr t2 lastn (num_consec + 1)
              | _ -> (num_consec lastn) :: (compr t2 h2 1)) in
       compr tail head 1 : (int * nucleobase) list)
;;compress [C; G; G; T; A; A]
