let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress ((first::rest as l) : nucleobase list) =
  (let rec compress_r dna sum last =
     match dna with
     | [] -> [sum last]
     | head::tail ->
         (match head with
          | last -> compress_r tail (sum + 1) head
          | _ -> (sum last) :: (compress_r tail 1 head)) in
   compress_r rest 1 first : (int * nucleobase) list)
;;compress [A; A; G; A]
