let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress (l : nucleobase list) =
  (let rec compress_r dna =
     match dna with | [] -> [] | head::tail -> (head 1) :: (compress_r tail) in
   compress_r l : (int * nucleobase) list)
;;compress [A; G; C]
