let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress (l : nucleobase list) =
  (let rec comp tides sum =
     match tides with
     | [] -> []
     | first::second::tail ->
         (match first with
          | second -> compress (second :: tail) (sum + 1)
          | _ -> (sum first) :: (compress (second :: tail) 1)) in
   comp l 1 compress [A; A; G; C] : (int * nucleobase) list)
