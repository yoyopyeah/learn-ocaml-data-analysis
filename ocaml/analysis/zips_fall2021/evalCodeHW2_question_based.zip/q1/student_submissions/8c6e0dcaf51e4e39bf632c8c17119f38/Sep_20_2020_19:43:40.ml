let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress (l : int list) =
  (match l with
   | [] -> []
   | h1::t1 ->
       let rec compr bases tuple =
         match bases with
         | [] -> [tuple]
         | head::tail ->
             let tuple = count base in
             (match base with
              | head -> compr tail (count + (1 head))
              | _ -> tuple :: (compr tail (1 head))) in
       compr t1 (1 h1) : (int * int) list)
;;compress [2; 3; 3; 4; 1; 1]
