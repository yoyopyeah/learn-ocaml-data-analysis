let compress_tests =
  [[];
  [A] [1 A];
  [A; C; G; T] [1 A; 1 C; 1 G; 1 T];
  [A; T; A] [1 A; 1 T; 1 A];
  [A; A; C; C; G; G; T; T] [2 A; 2 C; 2 G; 2 T];
  [G; A; T; T; A; C; A] [1 G; 1 A; 2 T; 1 A; 1 C; 1 A]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | head::tail ->
       let rec compr nlist base count =
         match nlist with
         | [] -> [count base]
         | h2::t2 ->
             (match base with
              | h2 -> compr t2 base (count + 1)
              | _ -> (count base) :: (compr t2 h2 1)) in
       compr tail head 1 : (int * nucleobase) list)
;;compress [C; G; G; T; A; A]
