let compress_tests =
  [[A; A; G; G; G; C; C; C; T] [2 A; 3 G; 3 C; 1 T];
  [];
  [A; G; C; T] [1 A; 1 G; 1 C; 1 T];
  [A; A; A; A; A; T] [5 A; 1 T]]
let compress (l : nucleobase list) =
  (let rec compress_tr count acc =
     function
     | [] -> []
     | x::[] -> (count + (1 x)) :: acc
     | x::(y::t as tail) ->
         if x = y
         then compress_tr (count + 1) acc tail
         else compress_tr 0 (((count + 1) x) :: acc) tail in
   compress_tr 0 [] l : (int * nucleobase) list)
let decompress_tests =
  [[];
  [1 A; 2 G; 2 C; 2 A] [A; G; G; C; C; A; A];
  [1 A; 3 T; 2 C; (1 G) (2 T)] [A; T; T; T; C; C; G; T; T]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
