let compress_tests = []
let compress (l : nucleobase list) =
  (let rec collapse (l : nucleobase list) (collapsed : chunk list) =
     (match l with
      | [] -> collapsed
      | h::t ->
          let n = count h l 0 in
          let snipped = snip n l in
          collapse snipped ({ i = n; b = h } :: collapsed) : chunk list) in
   collapse l [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
