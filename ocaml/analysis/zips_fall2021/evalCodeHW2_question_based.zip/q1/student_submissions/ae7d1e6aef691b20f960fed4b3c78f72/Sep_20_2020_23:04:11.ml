let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [A] [1 A];
  [A; C; G] [1 A; 1 C; 1 G];
  [A; A; A; A; A; A; A] [7 A];
  [A; A; C; G; T; T] [2 A; 1 C; 1 G; 2 T];
  []]
let compress (l : nucleobase list) =
  (let rec compress' l acc res =
     match l with
     | [] -> res
     | x::y::[] ->
         if x = y
         then compress' [] 0 (res @ [acc + (1 x)])
         else compress' [] 0 (res @ ([acc x] @ [1 y]))
     | x::y::t ->
         if x = y
         then compress' (y :: t) (acc + 1) res
         else compress' (y :: t) 1 (res @ [acc x])
     | x::[] -> compress' [] 0 [1 x] in
   compress' l 1 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
