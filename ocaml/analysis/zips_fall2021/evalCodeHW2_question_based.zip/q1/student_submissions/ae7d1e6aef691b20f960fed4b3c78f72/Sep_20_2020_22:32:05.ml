let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compress' l acc res =
     match l with
     | [] | _::[] -> res
     | x::y::t ->
         if x = y
         then compress' t (acc + 1) res
         else compress' t 0 ([acc x] @ res) in
   compress' l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
