let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [];
  [A; A; A; A; A; A; A; A; A; A; A; A; A; A; A; A; A; A; A] [19 A];
  [G; C; C; C; C; G; G; G; G; C; C; T; A; A] [1 G; 4 C; 4 G; 2 C; 1 T; 2 A];
  [G] [1 G]]
let compress (l : nucleobase list) =
  (let rec comp_tr l (comp_list : (int * nucleobase) list) last acc =
     match l with
     | [] -> comp_list
     | x::rest ->
         if acc = 0
         then comp_tr l comp_list x 1
         else
           if x = last
           then comp_tr rest comp_list last (acc + 1)
           else comp_tr rest (comp_list @ [acc x]) x 1 in
   comp_tr l [] T 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
