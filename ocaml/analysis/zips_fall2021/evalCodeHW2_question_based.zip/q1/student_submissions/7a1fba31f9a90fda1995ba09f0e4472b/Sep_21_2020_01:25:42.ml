let compress_tests = []
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | x::[] -> [1 x]
   | x::y::tl ->
       let rec count l acc =
         match l with
         | [] -> [acc x]
         | x::[] -> [acc x]
         | x::y::tl ->
             if x = y
             then count (y :: tl) (acc + 1)
             else (acc x) :: (count (y :: tl) 1) in
       count l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
