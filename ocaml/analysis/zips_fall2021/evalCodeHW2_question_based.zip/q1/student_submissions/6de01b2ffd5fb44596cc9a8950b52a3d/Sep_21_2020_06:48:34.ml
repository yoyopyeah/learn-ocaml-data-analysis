let compress_tests =
  [[];
  [A] [1 A];
  [A; A; G] [2 A; 1 G];
  [A; A; A; G; C; T; T] [3 A; 1 G; 1 C; 2 T]]
let compress (l : nucleobase list) =
  (let compHelp l nuc count =
     match l with
     | [] -> []
     | n::t ->
         if count = 0
         then n :: (compHelp l n 1)
         else
           if n = nuc
           then n :: ((compHelp l n count) + 1)
           else (count n) :: (compHelp l A 0) in
   compHelp l A 0 : (int * nucleobase) list)
let decompress_tests =
  [[]; [A] [1 A]; [AAG] [(2 A) (1 G)]; [AAAGCTT] [(3 A) (1 G) (1 C) (2 T)]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
