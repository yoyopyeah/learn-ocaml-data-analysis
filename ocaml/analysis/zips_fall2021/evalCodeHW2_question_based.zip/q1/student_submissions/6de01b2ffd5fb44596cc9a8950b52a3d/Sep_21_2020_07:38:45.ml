let compress_tests =
  [[];
  [A] [1 A];
  [A; A; G] [2 A; 1 G];
  [A; A; A; G; C; T; T] [3 A; 1 G; 1 C; 2 T]]
let compress (l : nucleobase list) =
  (let rec compHelp l count =
     match l with
     | [] -> []
     | n::next::[] -> if n = next then [count + (2 n)] else [count n; 1 next]
     | n::next::t ->
         if n = next
         then compHelp (next :: t) (count + 1)
         else (count + (1 n)) :: (compHelp (next :: t) 0) in
   compHelp l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
