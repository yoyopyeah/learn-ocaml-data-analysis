let compress_tests =
  [[A; A; A; G; G; T; T; C; C; C; T; T] [3 A; 2 G; 2 T; 3 C; 2 T]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
