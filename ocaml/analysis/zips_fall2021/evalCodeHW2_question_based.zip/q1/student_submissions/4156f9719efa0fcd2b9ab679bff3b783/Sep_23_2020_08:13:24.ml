let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let rec com list acc =
     match list with
     | [] -> []
     | h::[] -> [acc h]
     | h::o::hs ->
         if h = o
         then com (h :: hs) (acc + 1)
         else [acc h] @ (com (o :: hs) 1) in
   com l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
