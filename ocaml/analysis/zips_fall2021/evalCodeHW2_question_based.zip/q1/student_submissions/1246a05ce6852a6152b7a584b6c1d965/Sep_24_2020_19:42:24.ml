let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [A; A; A; A] [4 A]]
let compress (l : nucleobase list) =
  (let rec helper = match l with | [] -> 0 | x::xs -> 1 + (helper xs) in
   helper l : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
