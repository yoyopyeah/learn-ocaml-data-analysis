let compress_tests = [[4 A; 3 G; 2 T; 1 C]; [0 A]; [1 G]; [1 A; 1 A]; []]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = [[A; G; T; C]; [A; A]; [G]; []]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
