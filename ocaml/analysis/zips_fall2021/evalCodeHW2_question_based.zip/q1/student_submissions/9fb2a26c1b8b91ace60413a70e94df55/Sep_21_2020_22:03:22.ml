let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let rec compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | h::(x::tail as xs) ->
       if h = x then (2 h) :: (compress xs) else (1 h) :: (compress xs) : 
  (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
