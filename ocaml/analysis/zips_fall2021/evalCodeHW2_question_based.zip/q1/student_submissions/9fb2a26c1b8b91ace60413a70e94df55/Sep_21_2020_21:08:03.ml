let compress_tests =
  [[A; A; A; G; T; A; C; C; C; G] [3 A; 1 G; 1 T; 1 A; 3 C; 1 G]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
