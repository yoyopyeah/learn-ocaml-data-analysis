let compress_tests =
  [[A; A; A; G; T; A; C; C; C; G] [3 A; 1 G; 1 T; 1 A; 3 C; 1 G]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | i::[] -> [1 i]
   | h::(x::tail as xs) ->
       if h = x then (2 h) :: (compress xs) else (1 h) :: (compress xs) : 
  (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
