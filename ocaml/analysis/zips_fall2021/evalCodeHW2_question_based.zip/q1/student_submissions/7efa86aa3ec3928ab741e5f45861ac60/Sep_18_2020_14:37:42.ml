let compress_tests =
  [[] ([A; A] [2 A]) ([A; T; C; G] [1 A; 1 T; 1 C; 1 G])
     ([A; A; T; C; C; G; G; G] [2 A; 1 T; 2 C; 3 G])]
let compress (l : nucleobase list) =
  (let rec count l acc =
     match l with
     | [] -> []
     | x::[] -> [acc x]
     | x::(y::t as xs) ->
         if x = y
         then count xs (acc + 1)
         else
           (match x with
            | A -> [acc A] @ (count xs 1)
            | T -> [acc T] @ (count xs 1)
            | C -> [acc C] @ (count xs 1)
            | G -> [acc G] @ (count xs 1)) in
   count l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
