let compress_tests = []
let compress (l : nucleobase list) =
  (let rec count l acc =
     match l with
     | [] -> []
     | x::y::t ->
         if x = y
         then count (y :: t) (acc + 1)
         else
           (let l2 = count (y :: t) in
            match x with
            | A -> l2 :: (acc A)
            | T -> l2 @ (acc T)
            | C -> l2 @ (acc C)
            | G -> l2 @ (acc G)) in
   count l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
