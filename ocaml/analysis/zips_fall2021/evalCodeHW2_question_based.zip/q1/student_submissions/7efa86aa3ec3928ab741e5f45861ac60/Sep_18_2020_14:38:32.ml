let compress_tests = []
let compress (l : nucleobase list) =
  (let rec count l acc =
     match l with
     | [] -> []
     | x::[] -> [acc x]
     | x::(y::t as xs) ->
         if x = y
         then count xs (acc + 1)
         else
           (match x with
            | A -> [acc A] @ (count xs 1)
            | T -> [acc T] @ (count xs 1)
            | C -> [acc C] @ (count xs 1)
            | G -> [acc G] @ (count xs 1)) in
   count l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
