let compress_tests =
  [[A; A; A; A; A; A; A; A; A] [9 A]; [A] [1 A]; [A; C] [1 A; 1 C]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
