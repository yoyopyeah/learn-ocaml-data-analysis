let compress_tests = []
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
