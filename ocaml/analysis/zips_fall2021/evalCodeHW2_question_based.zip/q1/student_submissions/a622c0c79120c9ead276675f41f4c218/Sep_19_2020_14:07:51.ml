let compress_tests = [[A; A; A; A; A; T; T; T; T] [5 A; 4 T]; []; [T] [1 T]]
let compress (l : nucleobase list) =
  (let rec helper_compress (l : nucleobase list) (z : nucleobase) (a : int) =
     (match l with
      | [] -> []
      | z::xs -> [a + (1 z)] @ ((helper_compress xs z a) + 1)
      | x::xs -> helper_compress xs x 1 : (int * nucleobase) list) in
   helper_compress l raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [[]; [1 T; 2 A; 3 C; 4 G] [T; A; A; C; C; C; G; G; G; G]; [1 T] [T]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
