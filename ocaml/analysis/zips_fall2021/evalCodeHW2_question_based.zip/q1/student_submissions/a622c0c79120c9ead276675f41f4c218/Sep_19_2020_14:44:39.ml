let compress_tests = [[A; A; A; A; A; T; T; T; T] [5 A; 4 T]; []; [T] [1 T]]
let compress (l : nucleobase list) =
  (let rec helper_counting list base acc =
     match list with
     | [] -> 0
     | base::xs -> (helper_counting xs base acc) + 1 in
   match l with | [] -> [] | x::xs -> [helper_counting l x 1 x] : (int *
                                                                    nucleobase)
                                                                    list)
let decompress_tests =
  [[]; [1 T; 2 A; 3 C; 4 G] [T; A; A; C; C; C; G; G; G; G]; [1 T] [T]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
