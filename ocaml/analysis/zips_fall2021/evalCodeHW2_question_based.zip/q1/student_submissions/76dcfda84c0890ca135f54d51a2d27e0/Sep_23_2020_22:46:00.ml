let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compr acc l list =
     match l with
     | [] -> []
     | h::(h2::_ as t) ->
         if h == h2
         then compr (acc + 1) t ((acc h) :: list)
         else compr 0 t list in
   compr 0 l [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
