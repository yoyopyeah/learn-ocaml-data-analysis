let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compr prev_letter acc list l =
     match l with
     | [] -> list
     | x::t ->
         if x = prev_letter
         then compr x (acc + 1) list t
         else compr x 0 [(acc prev_letter) :: list] t in
   compr 'G' 0 [] l : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
