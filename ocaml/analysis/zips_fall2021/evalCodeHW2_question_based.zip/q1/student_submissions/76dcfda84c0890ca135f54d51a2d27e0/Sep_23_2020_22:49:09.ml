let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compr acc l list =
     match l with
     | [] -> []
     | n::[] -> (acc + (1 n)) :: list
     | h::(h2::_ as t) ->
         if h == h2
         then compr (acc + 1) t list
         else compr 0 t ((acc + (1 h)) :: list) in
   compr 0 l [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
