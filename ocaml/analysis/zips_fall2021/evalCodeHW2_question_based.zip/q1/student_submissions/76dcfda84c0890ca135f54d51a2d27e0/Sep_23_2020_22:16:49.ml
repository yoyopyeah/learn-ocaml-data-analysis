let compress_tests = []
let compress (l : nucleobase list) =
  (let rec compr prev_letter acc l list =
     match l with
     | [] -> list
     | x::t ->
         if x = prev_letter
         then compr x (acc + 1) t list
         else compr x 0 t ((acc prev_letter) :: list) in
   compr T 0 l [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
