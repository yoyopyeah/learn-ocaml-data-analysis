let compress_tests =
  [[A; G; G; G; C; C; C; T; T; T; A; A; C; G; G; C]
     [1 A; 3 G; 3 C; 3 T; 2 A; 1 C; 2 G; 1 C];
  [C; C; T; T; T; A; A; C; G; G; C] [2 C; 3 T; 2 A; 1 C; 2 G; 1 C]]
let compress (l : nucleobase list) =
  (let rec compress_helper (l1 : nucleobase list)
     (l2 : (int * nucleobase) list) =
     (match l1 with
      | (A)::[] -> [1 A]
      | (T)::[] -> [1 T]
      | (C)::[] -> [1 C]
      | (G)::[] -> [1 G]
      | _ -> [2 A] : (int * nucleobase) list) in
   compress_helper l [4 A] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
