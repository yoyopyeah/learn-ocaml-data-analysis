let compress_tests =
  [[C; C; C; G; G; A; A; T; T; T] [3 C; 2 G; 2 A; 3 T];
  [C; G; A] [1 C; 1 G; 1 A];
  [C] [1 C];
  []]
let compress (l : nucleobase list) =
  (let compressed = [] in
   let rec append l compressed lastElement counter itr =
     match l with
     | [] -> (counter A lastElement itr) :: compressed
     | head::tail ->
         if itr = 0
         then append tail compressed head (counter + 1) (itr + 1)
         else
           if head = lastElement
           then append tail compressed head (counter + 1) (itr + 1)
           else (counter head lastElement itr) ::
             (append tail compressed head 1 (itr + 1)) in
   append l compressed A 1 0 : (int * nucleobase * nucleobase * int) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
