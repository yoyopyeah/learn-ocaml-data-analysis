let compress_tests =
  [[C; C; C; G; G; A; A; T; T; T] [3 C; 2 G; 2 A; 3 T];
  [C; G; A] [1 C; 1 G; 1 A];
  [C] [1 C];
  []]
let compress (l : nucleobase list) =
  (let compressed = [] in
   let rec append l compressed itr lastElement =
     match l with
     | [] -> compressed
     | head::tail -> (1 head itr lastElement) ::
         (append tail compressed (itr + 1) head) in
   append l compressed 0 A : (int * nucleobase * int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
