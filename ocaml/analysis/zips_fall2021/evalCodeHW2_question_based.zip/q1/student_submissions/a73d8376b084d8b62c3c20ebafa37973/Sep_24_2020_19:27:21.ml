let compress_tests =
  [[C; C; C; G; G; A; A; T; T; T] [3 C; 2 G; 2 A; 3 T];
  [C; G; A] [1 C; 1 G; 1 A];
  [C] [1 C];
  []]
let compress (l : nucleobase list) =
  (let compressed = [] in
   let rec append l compressed acc =
     match l with
     | [] -> compressed
     | head::tail -> (1 head acc) :: (append tail compressed acc) in
   append l compressed None : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
