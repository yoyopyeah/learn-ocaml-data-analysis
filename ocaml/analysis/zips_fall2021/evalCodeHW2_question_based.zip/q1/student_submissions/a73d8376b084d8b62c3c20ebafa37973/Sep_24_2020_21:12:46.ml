let compress_tests =
  [[C; C; C; G; G; A; A; T; T; T] [3 C; 2 G; 2 A; 3 T];
  [C; G; A] [1 C; 1 G; 1 A];
  [C] [1 C];
  []]
let compress (l : nucleobase list) =
  (let compressed = [] in
   let rec append l compressed lastElement counter itr =
     match l with
     | [] -> (counter lastElement) :: compressed
     | head::tail ->
         if itr = 0
         then append tail compressed head 1 (itr + 1)
         else
           if head = lastElement
           then append tail compressed head (counter + 1) (itr + 1)
           else (counter lastElement) ::
             (append tail compressed head 1 (itr + 1)) in
   if (List.length l) > 0 then append l compressed A 1 0 else [] : (int *
                                                                    nucleobase)
                                                                    list)
let decompress_tests =
  [[3 C; 2 G; 2 A; 3 T] [C; C; C; G; G; A; A; T; T; T];
  [1 C; 1 G; 1 A] [C; G; A];
  [1 C] [C];
  []]
let rec decompress (l : (int * nucleobase) list) =
  (let decompressed = [] in
   let rec append l =
     match l with
     | [] -> decompressed
     | head::tail -> A :: (append decompressed) in
   append l : nucleobase list)
