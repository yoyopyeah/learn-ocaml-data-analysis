let compress_tests =
  [[];
  [A; A; A; A] [4 A];
  [A; C; T; G] [1 A; 1 C; 1 T; 1 G];
  [A; T; T; A] [1 A; 2 T; 1 A]]
let compress (l : nucleobase list) =
  (match l with | [] -> [] | w::l' -> [1 w] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
