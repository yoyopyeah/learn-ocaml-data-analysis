let compress_tests = []
let compress (l : nucleobase list) =
  (let rec countNucleobase (l : nucleobase list) (n : nucleobase) (i : int)
     (r : (int * nucleobase) list) =
     (match l with
      | [] -> r
      | x::l' ->
          (match x with
           | n -> (countNucleobase l' n i) + (1 r)
           | _ -> (countNucleobase l' x 1 r) :: (i n)) : (int * nucleobase)
                                                           list) in
   countNucleobase l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
