let compress_tests = []
let compress (l : nucleobase list) =
  (let rec countNucleobase l n i r =
     (match l with
      | [] -> r
      | x::l' ->
          (match x with
           | n -> (countNucleobase l' n i) + (1 r)
           | _ -> (countNucleobase l' x 1 r) :: (i n)) : (int * nucleobase)
                                                           list) in
   countNucleobase l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
