let compress_tests =
  [[];
  [A; A; T; T; C; C; G] [2 A; 2 T; 2 C; 1 G];
  [A] [1 A];
  [A; T; A; T] [1 A; 1 T; 1 A; 1 T]]
let compress (l : nucleobase list) =
  (let i = 1 in
   let rec compress2 tai inc =
     match l with
     | [] -> []
     | h::[] -> [1 h]
     | h1::h2::t::[] ->
         if h1 == h2
         then [(compress2 t i) + 1]
         else [i h1; compress2 h2; t 1] in
   compress2 l 1 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
