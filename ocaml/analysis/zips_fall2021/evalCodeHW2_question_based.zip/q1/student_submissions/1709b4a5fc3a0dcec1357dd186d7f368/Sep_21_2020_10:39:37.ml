let compress_tests =
  [[];
  [A; A; T; T; C; C; G] [2 A; 2 T; 2 C; 1 G];
  [A] [1 A];
  [A; T; A; T] [1 A; 1 T; 1 A; 1 T]]
let compress (l : nucleobase list) =
  (match l with
   | [] -> []
   | h::[] -> [1 h]
   | h::t::[] ->
       if h == (List.hd t)
       then
         [((List.length h)
         ::
         (List.hd t h)
         ::
         (List.hd t))
         ::
         (compress List.tl t)]
       else [(List.length h h) :: (compress t)] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
