let compress_tests = [[] []; [AA] [2 A]; [AATTCCG] [(2 A) (2 T) (2 C) (1 G)]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
