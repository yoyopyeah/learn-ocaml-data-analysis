let compress_tests = [[]; [A; A; T; T; C; C; G] [2 A; 2 T; 2 C; 1 G]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
