let compress_tests =
  [[];
  [A; A; T; T; C; C; G] [2 A; 2 T; 2 C; 1 G];
  [A] [1 A];
  [A; T; A; T] [1 A; 1 T; 1 A; 1 T]]
let compress (l : nucleobase list) =
  (match l with | [] -> [] | h::[] -> [1 h] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
