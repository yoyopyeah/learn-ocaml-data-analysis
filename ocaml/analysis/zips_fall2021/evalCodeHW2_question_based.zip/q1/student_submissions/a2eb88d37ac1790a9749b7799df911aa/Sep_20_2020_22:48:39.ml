let compress_tests = [[]; [A] [1 A]; [A; A; A; G; G] [3 A; 2 G]]
let compress (l : nucleobase list) =
  (let rec compress' count acc lst =
     match lst with
     | [] -> []
     | x::[] -> acc @ [count + (1 x)]
     | a::(b::_ as t) ->
         if a = b
         then compress' (count + 1) acc t
         else compress' 0 ((count + (1 a)) :: acc) t in
   compress' 0 [] l : (int * nucleobase) list)
;;compress [A; A; A; G]
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
