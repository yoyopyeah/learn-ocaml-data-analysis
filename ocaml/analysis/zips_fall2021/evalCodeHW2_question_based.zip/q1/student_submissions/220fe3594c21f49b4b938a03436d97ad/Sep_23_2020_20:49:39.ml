let compress_tests = []
let compress (l : nucleobase list) =
  (let rec check_rep (lst1 : nucleobase list) (acc : int)
     (lst2 : (int * nucleobase) list) =
     match lst1 with
     | [] -> []
     | x::(y::tail as xs) ->
         if x = y
         then (check_rep [xs] acc) + (1 lst2)
         else check_rep xs 0 ((acc x) @ lst2) in
   check_rep l 1 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
