let compress_tests =
  [[]; [A] [1 A]; [AA] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let rec check_rep (lst1 : nucleobase list) (acc : int)
     (lst2 : (int * nucleobase) list) =
     match lst1 with
     | [] -> []
     | x::[] -> [1 x]
     | x::(y::tail as xs) ->
         if x = y
         then check_rep xs (acc + 1) lst2
         else check_rep xs 0 (lst2 @ [acc x]) in
   check_rep l 1 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
