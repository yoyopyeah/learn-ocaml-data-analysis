let compress_tests = []
let compress (l : nucleobase list) =
  (let rec check_rep lst1 acc lst2 =
     match lst1 with
     | [] -> []
     | x::y::tail ->
         if x = y
         then (check_rep y) :: ((tail acc) + (1 lst2))
         else (check_rep y) :: (tail 0 ((acc x) @ lst2)) in
   check_rep l 0 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
