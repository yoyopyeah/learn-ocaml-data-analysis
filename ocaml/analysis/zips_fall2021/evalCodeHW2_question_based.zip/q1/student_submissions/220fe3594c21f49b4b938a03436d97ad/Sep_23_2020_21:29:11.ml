let compress_tests =
  [[];
  [A] [1 A];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C]]
let compress (l : nucleobase list) =
  (let rec check_rep lst1 acc lst2 =
     match lst1 with
     | [] -> lst2 @ []
     | x::[] -> lst2 @ [1 x]
     | x::(y::[] as xs) ->
         if x = y
         then check_rep xs (acc + 1) lst2
         else check_rep xs 1 (lst2 @ [acc x]) in
   check_rep l 1 [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
