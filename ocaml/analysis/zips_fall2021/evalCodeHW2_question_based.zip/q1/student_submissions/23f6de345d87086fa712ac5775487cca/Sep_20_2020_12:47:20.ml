let compress_tests =
  [[A; A; A; A; G; G; A; T; T; T; C; T; C]
     [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [];
  [G; A; T; C] [1 G; 1 A; 1 T; 1 C];
  [T] [1 T];
  [A; G; G; C; T; G; A; A; C; C] [1 A; 2 G; 1 C; 1 T; 1 G; 2 A; 2 C]]
let compress (l : nucleobase list) =
  (let rec compress' lst count nuc =
     match lst with
     | [] -> []
     | nuc'::[] -> if nuc = nuc' then [count + (1 nuc)] else [1 nuc']
     | nuc'::t ->
         if nuc = nuc'
         then compress' t (count + 1) nuc
         else (count nuc) :: (compress' t 1 nuc') in
   compress' l 0 A : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
