let compress_tests =
  [[C; A; G; T] [1 C; 1 A; 1 G; 1 T]; [A; A; C; C; A] [2 A; 2 C; 1 A]]
let compress (l : nucleobase list) =
  (let rec f count acc =
     match l with
     | [] -> []
     | nb::[] -> (count + (1 nb)) :: acc
     | item::(next_item::_ as list_of_items) ->
         if item = next_item
         then f (count + 1) acc
         else f 0 ((count + (1 item)) :: acc) in
   List.rev (f 0 []) : (int * nucleobase) list)
let decompress_tests = [[1 C; 1 A; 1 G; 1 T] [C; A; G; T]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
