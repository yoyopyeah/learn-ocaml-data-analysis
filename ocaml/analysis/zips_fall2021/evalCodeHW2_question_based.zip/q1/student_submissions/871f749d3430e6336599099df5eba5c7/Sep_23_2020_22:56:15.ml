let compress_tests =
  [[T; T; A; A; C; C; G] [2 T; 2 A; 2 C; 1 G];
  [A; A; A; A; C; C; G] [4 A; 2 C; 1 G];
  [A; A; A; A; A; A; A] [7 A];
  [];
  [A] [1 A]]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests =
  [[2 T; 2 A; 2 C; 1 G] [T; T; A; A; C; C; G];
  [4 A; 2 C; 1 G] [A; A; A; A; C; C; G];
  [7 A] [A; A; A; A; A; A; A];
  [];
  [1 A] [A]]
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
