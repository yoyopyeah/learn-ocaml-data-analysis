let compress_tests =
  [[A; G; C; T] [1 A; 1 G; 1 C; 1 T];
  [A; G; A; A] [1 A; 1 G; 2 A];
  [A] [1 A];
  []]
let compress (l : nucleobase list) =
  (raise NotImplemented : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
