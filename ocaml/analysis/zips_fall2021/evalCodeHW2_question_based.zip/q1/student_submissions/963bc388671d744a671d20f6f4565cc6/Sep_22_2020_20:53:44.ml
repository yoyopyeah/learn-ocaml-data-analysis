let compress_tests =
  [[A; G; C; T] [1 A; 1 G; 1 C; 1 T];
  [A; G; A; A] [1 A; 1 G; 2 A];
  [A] [1 A];
  []]
let compress (l : nucleobase list) =
  (let compress_inner l1 l2 =
     match l1 with | [] -> l2 | h::t -> l2 @ [count (h :: t) 0 h] in
   compress_inner l [] : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
