let compress_tests =
  [[];
  [A] [1 A];
  [G; C] [1 G; 1 C];
  [C; C; G] [2 C; 1 G];
  [T; T; T; T] [4 T];
  [A; A; A; A; G; G; A; T; T; T; C; T; C] [4 A; 2 G; 1 A; 3 T; 1 C; 1 T; 1 C];
  [G; T; T; A; T; T; C; A; G; A; C; C]
    [1 G; 2 T; 1 A; 2 T; 1 C; 1 A; 1 G; 1 A; 2 C]]
let compress (l : nucleobase list) =
  (let rec com l acc =
     match l with
     | [] -> []
     | h1::h2::t ->
         if h1 == h2
         then com (h2 :: t) (acc + 1)
         else (acc + (1 h1)) :: (com (h2 :: t) 0) in
   com l 0 : (int * nucleobase) list)
let decompress_tests = []
let rec decompress (l : (int * nucleobase) list) =
  (raise NotImplemented : nucleobase list)
