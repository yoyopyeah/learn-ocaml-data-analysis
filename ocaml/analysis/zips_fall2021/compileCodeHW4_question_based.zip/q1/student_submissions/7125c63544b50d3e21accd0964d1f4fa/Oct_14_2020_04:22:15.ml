let new_account (p : passwd) =
  (let password = ref p in
   let counter = ref 0 in
   {
     update_passwd =
       (fun old ->
          fun neu ->
            if old = (!password)
            then (password := neu) (counter := 0)
            else (counter := ((!counter) + 1)) wrong_pass);
     retrieve = (retrieve : passwd -> int -> unit);
     deposit = (deposit : passwd -> int -> unit);
     print_balance = (print_balance : passwd -> int)
   } : bank_account)
