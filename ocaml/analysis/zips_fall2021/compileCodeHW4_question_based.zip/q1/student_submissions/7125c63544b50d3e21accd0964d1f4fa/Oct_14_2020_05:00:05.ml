let new_account (p : passwd) =
  (let password = ref p in
   let counter = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun old ->
          fun neu ->
            if old = (!password)
            then let x = password := neu in counter := 0
            else
              (let y = counter := ((!counter) + 1) in raise (Msg wrong_pass)));
     retrieve =
       (fun pass ->
          fun amt ->
            if (!counter) > 3
            then raise Msg too_many_attempts
            else
              if pass = (!password)
              then
                (let x = counter := 0 in
                 if amt <= (!balance)
                 then balance := ((!balance) - amt)
                 else raise Msg no_money)
              else
                (let x = counter := ((!counter) + 1) in raise Msg wrong_pass));
     deposit =
       (fun pass ->
          fun amt ->
            if (!counter) > 3
            then raise Msg too_many_attempts
            else
              if pass = (!password)
              then (let x = counter := 0 in balance := ((!balance) + amt))
              else
                (let y = counter := ((!counter) + 1) in raise Msg wrong_pass));
     print_balance =
       (fun pass ->
          if (!counter) > 3
          then raise Msg too_many_attempts
          else
            if pass = (!password)
            then !balance
            else
              (let x = counter := ((!counter) + 1) in raise Msg wrong_pass))
   } : bank_account)
