let new_account (p : passwd) =
  (let password = ref p in
   let counter = ref 0 in
   let balance = ref 0 in
   {
     update_passwd =
       (fun old ->
          fun neu ->
            if old = (!password)
            then (password := neu; counter := 0)
            else (counter := ((!counter) + 1); raise wrong_pass));
     retrieve =
       (fun pass ->
          fun amt ->
            if (!counter) > 3
            then raise too_many_attempts
            else
              if pass = (!password)
              then
                (counter := 0;
                 if amt <= (!balance)
                 then balance := ((!balance) - amt)
                 else raise no_money)
              else (counter := ((!counter) + 1); raise wrong_pass));
     deposit =
       (fun pass ->
          fun amt ->
            if (!counter) > 3
            then raise too_many_attempts
            else
              if pass = (!password)
              then (counter := 0; balance := ((!balance) + amt))
              else (counter := ((!counter) + 1); raise wrong_pass));
     print_balance =
       (fun pass -> if (!counter) > 3 then raise too_many_attempts else ())
   } : bank_account)
