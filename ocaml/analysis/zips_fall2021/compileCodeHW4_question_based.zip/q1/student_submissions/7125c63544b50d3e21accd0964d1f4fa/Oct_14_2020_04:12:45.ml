let new_account (p : passwd) =
  (let password = ref p in
   {
     update_passwd = (update_passwd : passwd -> passwd -> unit);
     retrieve = (retrieve : passwd -> int -> unit);
     deposit = (deposit : passwd -> int -> unit);
     print_balance = (print_balance : passwd -> int)
   } : bank_account)
