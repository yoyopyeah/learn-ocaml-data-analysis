let new_account (p : passwd) =
  (let password = ref p in
   let counter = ref 0 in
   {
     update_passwd = (fun () -> fun old -> fun neu -> ());
     retrieve = (retrieve : passwd -> int -> unit);
     deposit = (deposit : passwd -> int -> unit);
     print_balance = (print_balance : passwd -> int)
   } : bank_account)
