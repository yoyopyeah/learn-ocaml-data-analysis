let new_account (p : passwd) =
  (let password = ref p
   and balance = ref 0
   and login_attempts = ref 0 in
   let check_login enteredpassword f =
     if enteredpassword = (!password)
     then login_attempts := 0
     else (login_attempts := ((!login_attempts) + 1); raise wrong_pass) in
   let check_attempts enteredpassword f =
     if (!login_attempts) > 2
     then raise too_many_attempts
     else check_login enteredpassword f in
   let update_passwd oldpassword newpassword =
     check_login oldpassword (fun () -> password := newpassword) in
   let deposit password money =
     check_attempts password (fun () -> balance := ((!balance) + money)) in
   let retrieve password money =
     if (!balance) < money
     then raise no_money
     else check_attempts password (fun () -> balance := ((!balance) - money)) in
   let print_balance password = check_attempts password (fun () -> !balance) in
   {
     update_passwd = (update_passwd : passwd -> passwd -> unit);
     retrieve = (retrieve : passwd -> int -> unit);
     deposit = (deposit : passwd -> int -> unit);
     print_balance = (print_balance : passwd -> int)
   } : bank_account)
