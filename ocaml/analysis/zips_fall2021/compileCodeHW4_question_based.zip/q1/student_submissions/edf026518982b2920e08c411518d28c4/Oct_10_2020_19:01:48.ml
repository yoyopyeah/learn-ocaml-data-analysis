let new_account (p : passwd) =
  (let passwd = ref p in
   let bal = ref 0 in
   let wrongs = ref 0 in
   {
     update_passwd =
       (fun inpasswd ->
          fun newpasswd ->
            if inpasswd = (!passwd)
            then (passwd := newpasswd; wrongs := 0)
            else raise wrong_pass;
            retrieve =
              ((fun inpasswd ->
                  fun withdrawal ->
                    if inpasswd = (!passwd)
                    then
                      (if withdrawal <= (!bal)
                       then bal := ((!bal) - withdrawal)
                       else raise no_money)
                    else wrongs := ((!wrongs) + 1);
                    raise wrong_pass;
                    deposit =
                      ((fun inpasswd ->
                          fun dep ->
                            if inpasswd = (!passwd)
                            then bal := ((!bal) + dep)
                            else wrongs := ((!wrongs) + 1);
                            raise wrong_pass;
                            print_balance =
                              ((fun inpasswd ->
                                  if inpasswd = (!passwd)
                                  then !bal
                                  else wrongs := ((!wrongs) + 1);
                                  raise wrong_pass)))))))
   } : bank_account)
