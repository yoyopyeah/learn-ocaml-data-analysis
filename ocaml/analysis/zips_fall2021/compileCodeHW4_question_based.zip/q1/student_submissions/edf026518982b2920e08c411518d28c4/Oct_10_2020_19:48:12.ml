let new_account (p : passwd) =
  (let passwd = ref p in
   let bal = ref 0 in
   let wrongs = ref 0 in
   {
     update_passwd =
       (fun inpasswd ->
          fun newpasswd ->
            if not String.equal inpasswd (!passwd)
            then (incr wrongs; raise wrong_pass)
            else (wrongs := 0; passwd := newpasswd));
     retrieve =
       (fun inpasswd ->
          fun withdrawal ->
            if (!wrongs) > 2
            then raise too_many_attempts
            else
              if inpasswd != (!passwd)
              then (incr wrongs; raise wrong_pass)
              else
                if withdrawal > (!bal)
                then raise no_money
                else (wrongs := 0; bal := ((!bal) - withdrawal)));
     deposit =
       (fun inpasswd ->
          fun dep ->
            if (!wrongs) > 2
            then raise too_many_attempts
            else
              if inpasswd != (!passwd)
              then (incr wrongs; raise wrong_pass)
              else (wrongs := 0; bal := ((!bal) + dep)));
     print_balance =
       (fun inpasswd ->
          if (!wrongs) > 2
          then raise too_many_attempts
          else
            if inpasswd != (!passwd)
            then (incr wrongs; raise wrong_pass)
            else (wrongs := 0; !bal))
   } : bank_account)
