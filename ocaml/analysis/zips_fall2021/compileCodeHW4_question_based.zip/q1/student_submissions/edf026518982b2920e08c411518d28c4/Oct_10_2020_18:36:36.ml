let new_account (p : passwd) =
  (let passwd = ref p in
   {
     update_passwd = (update_passwd : passwd -> passwd -> unit);
     retrieve = (retrieve : passwd -> int -> unit);
     deposit = (deposit : passwd -> int -> unit);
     print_balance = (print_balance : passwd -> int)
   } raise NotImplemented : bank_account)
