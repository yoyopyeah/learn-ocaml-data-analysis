let fact_tests =
  [0 1.; 1 1.; 2 2.; 5 120.; 10 3628800.; 8 40320.; 11 39916800.]
let rec fact (n : int) =
  (if n < 0
   then raise NotImplemented
   else (match n with | 0 -> 1. | n -> (float_of_int n) *. (fact (n - 1))) : 
  float)
let binomial_tests =
  [(1 0) 1.;
  (2 0) 1.;
  (10 1) 10.;
  (10 2) 45.;
  (0 1) domain ();
  (0 (-1)) domain ();
  ((-1) 0) domain ();
  ((-1) (-1)) domain ();
  (1 2) domain ()]
let binomial (n : int) (k : int) =
  if n < 0
  then domain ()
  else
    if k < 0
    then domain ()
    else
      if k > n then domain () else (fact n) /. ((fact k) *. (fact (n - k)))
let ackerman_tests =
  [(0 0) 1;
  (0 1) 2;
  (1 0) 2;
  (1 1) 3;
  (2 0) 3;
  (3 0) 5;
  (0 2) 3;
  (0 3) 4;
  (2 2) 7]
