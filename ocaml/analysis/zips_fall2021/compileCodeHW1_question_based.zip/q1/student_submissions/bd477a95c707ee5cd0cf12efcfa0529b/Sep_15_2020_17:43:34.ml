let fact_tests = [0 1.; 1 1.; 2 2.; 3 6.; 4 24.; 5 120.]
let rec fact (n : int) =
  (match n with | 0 -> 1.0 | _ -> (fact n) *. (fact (n - 1)) : float)
