let fact_tests = [3 6.; 9 362880.; 0 1.; 1 1.; 2 2.; 5 120.]
let rec fact (n : int) =
  (match n with | 0 -> 1. | _ -> (float_of_int n) *. (fact (n - 1)) : 
  float)
