let new_account (p : passwd) =
  (let password = ref p in
   let balance = ref 0 in
   let block = ref 0 in
   {
     update_passwd =
       (fun (op : passwd) ->
          fun (np : passwd) ->
            if op = p
            then (let p = !password in let block = ref 0 in password := np)
            else block := ((!block) + 1);
            raise wrong_pass);
     deposit =
       (fun (op : passwd) ->
          fun (amount : int) ->
            if (!block) > 2
            then
              (if p = op
               then (let block = ref 0 in balance := ((!balance) + amount))
               else block := ((!block) + 1);
               raise wrong_pass)
            else raise too_many_attempts);
     retrieve =
       (fun (op : passwd) ->
          fun (amount : int) ->
            if (!block) > 2
            then
              (if p = op
               then
                 (let block = ref 0 in
                  if (!balance) < amount
                  then balance := ((!balance) - amount)
                  else raise no_money)
               else block := ((!block) + 1);
               raise wrong_pass)
            else raise too_many_attempts);
     print_balance =
       (fun (op : passwd) ->
          if (!block) > 2
          then
            let block = ref 0 in
            (if op = p
             then !balance
             else (let block = ref ((!block) + 1) in raise wrong_pass))
          else raise too_many_attempts)
   } : bank_account)
