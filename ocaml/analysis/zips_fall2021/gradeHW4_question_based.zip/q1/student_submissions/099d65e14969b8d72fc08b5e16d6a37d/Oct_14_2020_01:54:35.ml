let new_account (p : passwd) =
  (let password = ref p in
   let balance = ref 0 in
   let block = ref 0 in
   {
     update_passwd =
       (fun (op : passwd) ->
          fun (np : passwd) ->
            if op = (!password)
            then (password := np; block := 0)
            else block := ((!block) + 1);
            raise wrong_pass);
     deposit =
       (fun (op : passwd) ->
          fun (amount : int) ->
            if (!block) < 3
            then
              (if password == (ref op)
               then (block := 0; balance := ((!balance) + amount))
               else block := ((!block) + 1);
               raise wrong_pass)
            else raise too_many_attempts);
     retrieve =
       (fun (op : passwd) ->
          fun (amount : int) ->
            if (!block) < 3
            then
              (if password == (ref op)
               then
                 (block := 0;
                  if (!balance) < amount
                  then balance := ((!balance) - amount)
                  else raise no_money)
               else (block := ((!block) + 1); raise wrong_pass))
            else raise too_many_attempts);
     print_balance =
       (fun (op : passwd) ->
          if (!block) < 3
          then
            (if op == (!password)
             then (block := 0; !balance)
             else (block := ((!block) + 1); raise wrong_pass))
          else raise too_many_attempts)
   } : bank_account)
