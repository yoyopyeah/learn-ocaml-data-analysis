let new_account (p : passwd) =
  (let curPass = ref p in
   let balance = ref 0 in
   let numAttempts = ref 0 in
   let warn_passwd =
     if (!numAttempts) > 3
     then raise too_many_attempts
     else
       (try raise wrong_pass
        with | wrong_pass -> numAttempts := ((!numAttempts) + 1)) in
   let checkPass (pass : passwd) =
     if pass = (!curPass) then numAttempts := 0 else raise wrong_pass in
   let update_passwd (oldPass : passwd) (newPass : passwd) =
     if oldPass = (!curPass) then curPass := newPass else warn_passwd in
   let deposit (p : passwd) (add : int) =
     if p = (!curPass) then balance := ((!balance) + add) else warn_passwd in
   let retrieve (p : passwd) (remove : int) =
     if p = (!curPass)
     then
       (if remove <= (!balance)
        then balance := ((!balance) - remove)
        else raise no_money)
     else warn_passwd in
   let print_balance (p : passwd) =
     if p = (!curPass) then !balance else raise wrong_pass in
   let x = { update_passwd; retrieve; deposit; print_balance } in x : 
  bank_account)
