let new_account (p : passwd) =
  (let curPass = ref p in
   let balance = ref 0 in
   let numAttempts = ref 0 in
   let lock_acct = if (!numAttempts) > 3 then raise too_many_attempts in
   let checkPass (pass : passwd) =
     if pass = (!curPass)
     then true
     else (lock_acct; numAttempts := ((!numAttempts) + 1); raise wrong_pass) in
   let update_passwd (oldPass : passwd) (newPass : passwd) =
     if checkPass oldPass then curPass := newPass in
   let deposit (p : passwd) (add : int) =
     if checkPass p then balance := ((!balance) + add) in
   let retrieve (p : passwd) (remove : int) =
     if checkPass p
     then
       (if remove <= (!balance)
        then balance := ((!balance) - remove)
        else raise no_money) in
   let print_balance (p : passwd) = if checkPass p then !balance else 0 in
   { update_passwd; retrieve; deposit; print_balance } : bank_account)
