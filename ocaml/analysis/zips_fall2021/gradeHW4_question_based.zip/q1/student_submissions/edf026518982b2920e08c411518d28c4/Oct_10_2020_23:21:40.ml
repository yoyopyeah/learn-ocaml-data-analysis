let new_account (p : passwd) =
  (let passwd = ref p in
   let bal = ref 0 in
   let wrongs = ref 0 in
   {
     update_passwd =
       (fun inpasswd ->
          fun newpasswd ->
            if inpasswd != (!passwd)
            then raise wrong_pass
            else (passwd := newpasswd; wrongs := 0));
     retrieve =
       (fun inpasswd ->
          fun withdrawal ->
            if (!wrongs) > 3
            then raise too_many_attempts
            else
              if inpasswd != (!passwd)
              then (incr wrongs; raise wrong_pass)
              else
                if withdrawal > (!bal)
                then raise no_money
                else bal := ((!bal) - withdrawal));
     deposit =
       (fun inpasswd ->
          fun dep ->
            if (!wrongs) > 3
            then raise too_many_attempts
            else
              if inpasswd != (!passwd)
              then (incr wrongs; raise wrong_pass)
              else bal := ((!bal) + dep));
     print_balance =
       (fun inpasswd ->
          if (!wrongs) > 3
          then raise too_many_attempts
          else
            if inpasswd != (!passwd)
            then (incr wrongs; raise wrong_pass)
            else !bal)
   } : bank_account)
