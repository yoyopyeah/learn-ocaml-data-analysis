let fact_tests = [(0, 1.); (1, 1.); (2, 2.); (5, 120.)]
let rec fact (n : int) =
  (match n with | 0 -> 1. | 1 -> 1. | _ -> (float n) *. (fact (n - 1)) : 
  float)
let binomial_tests =
  [((0, 0), 1.); ((1, 0), 1.); ((2, 0), 1.); ((10, 1), 10.); ((10, 2), 45.)]
let binomial (n : int) (k : int) =
  if (n < 0) || (k < 0)
  then raise NotImplemented
  else (fact n) /. ((fact k) *. (fact (n - k)))
let ackerman_tests =
  [((0, 1), 2);
  ((0, 0), 1);
  ((1, 0), 2);
  ((3, 1), 13);
  ((1, 3), 5);
  ((3, 5), 253)]
let ackerman (n, k) =
  if (n < 0) || (n < 0)
  then raise NotImplemented
  else
    (let rec ack n k =
       match (n, k) with
       | (0, 0) -> 1
       | (0, _) -> k + 1
       | (_, 0) -> ack (n - 1) 1
       | (_, _) -> ack (n - 1) (ack n (k - 1)) in
     ack n k)
