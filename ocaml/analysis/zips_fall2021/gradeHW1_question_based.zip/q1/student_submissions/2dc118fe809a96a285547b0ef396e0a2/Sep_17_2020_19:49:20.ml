let fact_tests = [(0, 1.); (1, 1.); (2, 2.); (5, 120.)]
let rec fact (n : int) =
  (let rec f n accum =
     if n = 0 then float_of_int accum else f (n - 1) (n * accum) in
   if n < 0 then domain () else f n 1 : float)
let binomial_tests =
  [((0, 0), 1.); ((1, 0), 1.); ((2, 0), 1.); ((10, 1), 10.); ((10, 2), 45.)]
let binomial (n : int) (k : int) =
  if n < 0
  then domain ()
  else if k = n then 1. else (fact n) /. ((fact k) *. (fact (n - k)))
let ackerman_tests =
  [((0, 0), 1);
  ((0, 1), 2);
  ((0, 5), 6);
  ((1, 0), 2);
  ((2, 0), 3);
  ((1, 1), 3)]
let ackerman (n, k) =
  if (n < 0) || (k < 0)
  then domain ()
  else
    (let rec ack n k =
       match (n, k) with
       | (0, k) -> k + 1
       | (n, 0) -> ack (n - 1) 1
       | (n, k) -> ack (n - 1) (ack n (k - 1)) in
     ack n k)
