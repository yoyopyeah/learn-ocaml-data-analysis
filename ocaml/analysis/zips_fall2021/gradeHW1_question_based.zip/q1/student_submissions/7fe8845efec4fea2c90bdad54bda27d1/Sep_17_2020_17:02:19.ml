let fact_tests =
  [(0, 1.0);
  (1, 1.0);
  (2, 2.0);
  (3, 6.0);
  (4, 24.0);
  (5, 120.0);
  (10, 3628800.0)]
let fact (n : int) =
  (match n > 0 with | false -> 1.0 | true -> fastfact (float_of_int n) : 
  float)
let binomial_tests =
  [((0, 0), 1.); ((1, 0), 1.); ((2, 0), 1.); ((10, 1), 10.); ((10, 2), 45.)]
let binomial (n : int) (k : int) =
  (if n < 0
   then domain ()
   else if k > n then domain () else (fact n) /. ((fact k) *. (fact (n - k))) : 
  float)
let ackerman_tests =
  [((0, 1), 2);
  ((1, 0), 2);
  ((1, 1), 3);
  ((0, 2), 3);
  ((2, 0), 3);
  ((2, 2), 7);
  ((0, 3), 4);
  ((3, 0), 5);
  ((3, 3), 61)]
let ackerman ((n, k) : (int * int)) =
  (if (n < 0) && (k < 0)
   then domain ()
   else
     (let rec ack n k =
        match (n, k) with
        | (0, _) -> k + 1
        | (_, 0) -> ack (n - 1) 1
        | (_, _) -> ack (n - 1) (ack n (k - 1)) in
      ack n k) : int)
