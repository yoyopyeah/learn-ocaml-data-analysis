let fact_tests = [(0, 1.0); (1, 1.0); (2, 2.0); (5, 120.0)]
let rec fact (n : int) =
  (match n with | 0 -> 1.0 | _ -> (float n) *. (fact (n - 1)) : float)
let binomial_tests =
  [((0, 0), 0.); ((1, 0), 0.); ((2, 0), 1.); ((10, 1), 1.); ((10, 2), 1.)]
let binomial (n : int) (k : int) =
  if n < 0
  then domain ()
  else if k = n then domain () else (fact k) /. ((fact n) *. (fact (k - n)))
let ackerman_tests = []
let ackerman (n, k) =
  if (n < 0) || (n < 0)
  then domain ()
  else
    (let rec ack n k =
       match (n, k) with
       | (_, 0) -> k + 1
       | (0, _) -> (ack n 1) - 1
       | (_, _) -> ack (n - 1) (ack n (k - 1)) in
     ack n k)
