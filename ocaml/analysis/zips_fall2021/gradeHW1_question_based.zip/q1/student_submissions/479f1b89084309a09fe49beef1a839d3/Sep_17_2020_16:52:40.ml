let fact_tests = [(0, 1.); (1, 1.); (3, 6.); (5, 120.)]
let fact n =
  let rec fact' (n : int) (acc : float) =
    (match n with | 0 -> acc | _ -> fact' (n - 1) ((float n) *. acc) : 
    float) in
  if n < 0 then raise NotImplemented else fact' n 1.0
let binomial_tests =
  [((0, 0), 1.);
  ((1, 0), 1.);
  ((2, 0), 1.);
  ((5, 3), 10.);
  ((10, 1), 10.);
  ((10, 2), 45.)]
let binomial (n : int) (k : int) =
  if n < 0
  then raise NotImplemented
  else if k = n then 1.0 else (fact n) /. ((fact k) *. (fact (n - k)))
let ackerman_tests = [((0, 3), 4); ((1, 0), 2); ((1, 2), 4); ((2, 5), 13)]
let ackerman (n, k) =
  let rec ack n k =
    match (n, k) with
    | (0, _) -> k + 1
    | (_, 0) -> ack (n - 1) 1
    | (_, _) -> ack (n - 1) (ack n (k - 1)) in
  if (n < 0) || (k < 0) then raise NotImplemented else ack n k
