let fact_tests = [(0, 1.); (1, 1.); (2, 2.); (5, 120.)]
let rec fact (n : int) =
  (match n with
   | 0 -> 1.0
   | 1 -> 1.0
   | _ -> (float_of_int n) *. (fact (n - 1)) : float)
let binomial_tests =
  [((0, 0), 1.); ((1, 0), 1.); ((2, 0), 1.); ((10, 1), 10.); ((10, 2), 45.)]
let binomial (n : int) (k : int) =
  if k = n
  then 1.
  else if k = 0 then 1. else (fact n) /. ((fact k) *. (fact (n - k)))
let ackerman_tests =
  [((0, 0), 1);
  ((0, 5), 6);
  ((1, 0), 2);
  ((1, 1), 3);
  ((1, 2), 4);
  ((1, 3), 5);
  ((1, 4), 6);
  ((2, 1), 5);
  ((2, 2), 7)]
let ackerman (n, k) =
  if (n < 0) || (n < 0)
  then domain ()
  else
    (let rec ack n k =
       match (n, k) with
       | (_, 0) -> k + 1
       | (0, _) -> (ack n 1) - 1
       | (_, _) -> ack (n - 1) (ack n (k - 1)) in
     ack n k)
